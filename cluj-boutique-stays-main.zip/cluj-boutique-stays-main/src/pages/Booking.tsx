import { useState } from "react";
import { motion } from "framer-motion";
import { LayoutGrid, List } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import BookingSearchBar from "@/components/booking/BookingSearchBar";
import RoomCard from "@/components/booking/RoomCard";
import { rooms } from "@/lib/roomData";

const Booking = () => {
  const [viewMode, setViewMode] = useState<"grid" | "list">("list");

  return (
    <div className="min-h-screen bg-background">
      <Header />

      {/* Hero Banner */}
      <section className="pt-24 pb-8 lg:pt-32 lg:pb-12 bg-foreground">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-center"
          >
            <p className="font-body text-sm uppercase tracking-[0.2em] text-primary mb-3">Reservations</p>
            <h1 className="font-display text-3xl md:text-4xl lg:text-5xl font-semibold text-background mb-4">
              Book Your Stay
            </h1>
            <p className="font-body text-background/60 max-w-xl mx-auto">
              Select your dates and explore our boutique rooms in the heart of Cluj-Napoca.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Search Bar */}
      <div className="container mx-auto px-4 -mt-1">
        <BookingSearchBar className="relative -top-0 border-t-0 rounded-t-none" />
      </div>

      {/* Results */}
      <section className="py-12 lg:py-16">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h2 className="font-display text-2xl font-semibold text-foreground">{rooms.length} Rooms Available</h2>
              <p className="font-body text-sm text-muted-foreground mt-1">Ferdinand Boutique Cluj-Napoca</p>
            </div>
            <div className="hidden md:flex items-center gap-1 border border-border rounded-sm p-1">
              <button
                onClick={() => setViewMode("grid")}
                className={`p-2 rounded-sm transition-colors ${viewMode === "grid" ? "bg-secondary text-foreground" : "text-muted-foreground hover:text-foreground"}`}
              >
                <LayoutGrid size={18} />
              </button>
              <button
                onClick={() => setViewMode("list")}
                className={`p-2 rounded-sm transition-colors ${viewMode === "list" ? "bg-secondary text-foreground" : "text-muted-foreground hover:text-foreground"}`}
              >
                <List size={18} />
              </button>
            </div>
          </div>

          <div className={viewMode === "grid" ? "grid md:grid-cols-2 gap-6" : "flex flex-col gap-6"}>
            {rooms.map((room, i) => (
              <RoomCard key={room.id} room={room} index={i} variant={viewMode} />
            ))}
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Booking;

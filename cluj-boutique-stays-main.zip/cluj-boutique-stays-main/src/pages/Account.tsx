import { useState } from "react";
import { motion } from "framer-motion";
import { User, CalendarDays, Settings, LogOut, Mail, Phone, MapPin } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

const tabs = [
  { id: "profile", label: "Profile", icon: User },
  { id: "bookings", label: "Bookings", icon: CalendarDays },
  { id: "settings", label: "Settings", icon: Settings },
];

const mockBookings = [
  { id: "FB-2024-001", room: "Double Room", checkIn: "2024-12-20", checkOut: "2024-12-23", status: "Confirmed", total: "€195" },
  { id: "FB-2024-002", room: "Apartment", checkIn: "2025-01-15", checkOut: "2025-01-18", status: "Completed", total: "€285" },
  { id: "FB-2024-003", room: "Triple Room", checkIn: "2025-03-10", checkOut: "2025-03-12", status: "Upcoming", total: "€170" },
];

const Account = () => {
  const [activeTab, setActiveTab] = useState("profile");

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <section className="pt-28 pb-16 lg:pt-36 lg:pb-24">
        <div className="container mx-auto px-4">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
            {/* Header */}
            <div className="flex flex-col md:flex-row md:items-center justify-between mb-10">
              <div>
                <h1 className="font-display text-3xl font-semibold text-foreground mb-1">My Account</h1>
                <p className="font-body text-sm text-muted-foreground">Manage your profile and view booking history</p>
              </div>
              <Button variant="outline" className="mt-4 md:mt-0 gap-2 rounded-sm font-body text-sm">
                <LogOut size={16} /> Sign Out
              </Button>
            </div>

            <div className="grid lg:grid-cols-4 gap-8">
              {/* Sidebar */}
              <div className="lg:col-span-1">
                <div className="bg-card border border-border rounded-sm overflow-hidden">
                  <div className="p-6 border-b border-border text-center">
                    <div className="w-16 h-16 rounded-full bg-secondary flex items-center justify-center mx-auto mb-3">
                      <User className="text-primary" size={28} />
                    </div>
                    <h3 className="font-display text-lg font-semibold text-foreground">Guest User</h3>
                    <p className="font-body text-xs text-muted-foreground">guest@email.com</p>
                  </div>
                  <nav className="p-2">
                    {tabs.map((tab) => (
                      <button
                        key={tab.id}
                        onClick={() => setActiveTab(tab.id)}
                        className={`w-full flex items-center gap-3 px-4 py-3 rounded-sm font-body text-sm transition-colors ${
                          activeTab === tab.id ? "bg-secondary text-foreground font-medium" : "text-muted-foreground hover:bg-secondary/50"
                        }`}
                      >
                        <tab.icon size={16} /> {tab.label}
                      </button>
                    ))}
                  </nav>
                </div>
              </div>

              {/* Content */}
              <div className="lg:col-span-3">
                {activeTab === "profile" && (
                  <div className="bg-card border border-border rounded-sm p-6 lg:p-8">
                    <h2 className="font-display text-2xl font-semibold text-foreground mb-6">Profile Details</h2>
                    <div className="grid md:grid-cols-2 gap-5">
                      <div>
                        <label className="font-body text-sm font-medium text-foreground mb-1.5 block">First Name</label>
                        <div className="relative">
                          <User className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                          <Input defaultValue="Guest" className="pl-10 h-12 rounded-sm font-body" />
                        </div>
                      </div>
                      <div>
                        <label className="font-body text-sm font-medium text-foreground mb-1.5 block">Last Name</label>
                        <Input defaultValue="User" className="h-12 rounded-sm font-body" />
                      </div>
                      <div>
                        <label className="font-body text-sm font-medium text-foreground mb-1.5 block">Email</label>
                        <div className="relative">
                          <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                          <Input defaultValue="guest@email.com" className="pl-10 h-12 rounded-sm font-body" />
                        </div>
                      </div>
                      <div>
                        <label className="font-body text-sm font-medium text-foreground mb-1.5 block">Phone</label>
                        <div className="relative">
                          <Phone className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                          <Input defaultValue="+40 740 228 899" className="pl-10 h-12 rounded-sm font-body" />
                        </div>
                      </div>
                      <div className="md:col-span-2">
                        <label className="font-body text-sm font-medium text-foreground mb-1.5 block">Address</label>
                        <div className="relative">
                          <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                          <Input placeholder="Your address" className="pl-10 h-12 rounded-sm font-body" />
                        </div>
                      </div>
                    </div>
                    <Button className="mt-6 bg-primary text-primary-foreground hover:bg-gold-dark font-body font-semibold rounded-sm">
                      Save Changes
                    </Button>
                  </div>
                )}

                {activeTab === "bookings" && (
                  <div className="bg-card border border-border rounded-sm p-6 lg:p-8">
                    <h2 className="font-display text-2xl font-semibold text-foreground mb-6">Booking History</h2>
                    <div className="space-y-4">
                      {mockBookings.map((booking) => (
                        <div key={booking.id} className="flex flex-col md:flex-row md:items-center justify-between p-5 bg-secondary rounded-sm gap-4">
                          <div className="flex-1">
                            <div className="flex items-center gap-3 mb-1">
                              <h3 className="font-display text-lg font-semibold text-foreground">{booking.room}</h3>
                              <span className={`px-2 py-0.5 rounded-sm font-body text-xs font-medium ${
                                booking.status === "Confirmed" ? "bg-primary/10 text-primary" :
                                booking.status === "Upcoming" ? "bg-blue-50 text-blue-700" :
                                "bg-muted text-muted-foreground"
                              }`}>
                                {booking.status}
                              </span>
                            </div>
                            <p className="font-body text-sm text-muted-foreground">
                              {booking.checkIn} → {booking.checkOut} · Ref: {booking.id}
                            </p>
                          </div>
                          <div className="text-right">
                            <p className="font-display text-xl font-semibold text-foreground">{booking.total}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {activeTab === "settings" && (
                  <div className="bg-card border border-border rounded-sm p-6 lg:p-8">
                    <h2 className="font-display text-2xl font-semibold text-foreground mb-6">Account Settings</h2>
                    <div className="space-y-6">
                      <div className="p-5 bg-secondary rounded-sm">
                        <h3 className="font-body text-sm font-semibold text-foreground mb-2">Change Password</h3>
                        <p className="font-body text-sm text-muted-foreground mb-4">Update your password to keep your account secure.</p>
                        <Button variant="outline" className="rounded-sm font-body text-sm">Update Password</Button>
                      </div>
                      <div className="p-5 bg-secondary rounded-sm">
                        <h3 className="font-body text-sm font-semibold text-foreground mb-2">Email Preferences</h3>
                        <p className="font-body text-sm text-muted-foreground mb-4">Manage your notification and marketing email preferences.</p>
                        <Button variant="outline" className="rounded-sm font-body text-sm">Manage Preferences</Button>
                      </div>
                      <div className="p-5 border border-destructive/20 rounded-sm">
                        <h3 className="font-body text-sm font-semibold text-destructive mb-2">Delete Account</h3>
                        <p className="font-body text-sm text-muted-foreground mb-4">Permanently delete your account and all associated data.</p>
                        <Button variant="destructive" className="rounded-sm font-body text-sm">Delete Account</Button>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </motion.div>
        </div>
      </section>
      <Footer />
    </div>
  );
};

export default Account;

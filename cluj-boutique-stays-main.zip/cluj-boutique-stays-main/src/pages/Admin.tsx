import { useState } from "react";
import { motion } from "framer-motion";
import {
  LayoutDashboard, BedDouble, ImageIcon, FileText, Star, HelpCircle,
  Share2, Phone, Shield, Search, Settings, ChevronRight, Eye, Users
} from "lucide-react";
import { Input } from "@/components/ui/input";
import AdminDashboard from "@/components/admin/AdminDashboard";
import AdminRooms from "@/components/admin/AdminRooms";
import AdminPhotos from "@/components/admin/AdminPhotos";
import AdminHomepage from "@/components/admin/AdminHomepage";
import AdminAmenities from "@/components/admin/AdminAmenities";
import AdminReviews from "@/components/admin/AdminReviews";
import AdminFAQ from "@/components/admin/AdminFAQ";
import AdminSocial from "@/components/admin/AdminSocial";
import AdminContact from "@/components/admin/AdminContact";
import AdminGuests from "@/components/admin/AdminGuests";
import AdminPolicies from "@/components/admin/AdminPolicies";
import AdminSEO from "@/components/admin/AdminSEO";

const sidebarItems = [
  { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
  { id: "rooms", label: "Rooms", icon: BedDouble },
  { id: "photos", label: "Photos", icon: ImageIcon },
  { id: "homepage", label: "Homepage", icon: FileText },
  { id: "amenities", label: "Amenities", icon: Settings },
  { id: "reviews", label: "Reviews", icon: Star },
  { id: "faq", label: "FAQ", icon: HelpCircle },
  { id: "social", label: "Social Media", icon: Share2 },
  { id: "contact", label: "Contact", icon: Phone },
  { id: "guests", label: "Guests / CRM", icon: Users },
  { id: "policies", label: "Policies", icon: Shield },
  { id: "seo", label: "SEO / Meta", icon: Search },
];

const sectionComponents: Record<string, React.ComponentType> = {
  dashboard: AdminDashboard,
  rooms: AdminRooms,
  photos: AdminPhotos,
  homepage: AdminHomepage,
  amenities: AdminAmenities,
  reviews: AdminReviews,
  faq: AdminFAQ,
  social: AdminSocial,
  contact: AdminContact,
  guests: AdminGuests,
  policies: AdminPolicies,
  seo: AdminSEO,
};

const Admin = () => {
  const [activeSection, setActiveSection] = useState("dashboard");
  const [sidebarOpen, setSidebarOpen] = useState(true);

  const ActiveComponent = sectionComponents[activeSection];

  return (
    <div className="min-h-screen bg-background flex">
      {/* Sidebar */}
      <aside className={`${sidebarOpen ? "w-64" : "w-16"} bg-foreground text-background transition-all duration-300 flex flex-col flex-shrink-0`}>
        <div className="p-4 border-b border-background/10">
          <div className="flex items-center justify-between">
            {sidebarOpen && (
              <h1 className="font-display text-lg font-semibold">
                Ferdinand <span className="text-primary">Admin</span>
              </h1>
            )}
            <button onClick={() => setSidebarOpen(!sidebarOpen)} className="p-1 text-background/60 hover:text-background">
              <ChevronRight size={18} className={`transition-transform ${sidebarOpen ? "rotate-180" : ""}`} />
            </button>
          </div>
        </div>
        <nav className="flex-1 p-2 space-y-0.5 overflow-y-auto">
          {sidebarItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveSection(item.id)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-sm text-sm font-body transition-colors ${
                activeSection === item.id
                  ? "bg-primary text-primary-foreground font-medium"
                  : "text-background/60 hover:text-background hover:bg-background/10"
              }`}
            >
              <item.icon size={18} />
              {sidebarOpen && item.label}
            </button>
          ))}
        </nav>
        <div className="p-4 border-t border-background/10">
          {sidebarOpen && (
            <a href="/" target="_blank" className="flex items-center gap-2 font-body text-xs text-background/40 hover:text-background/60 transition-colors">
              <Eye size={14} /> View Live Site
            </a>
          )}
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto">
        <header className="bg-card border-b border-border px-6 py-4 flex items-center justify-between sticky top-0 z-10">
          <h2 className="font-display text-xl font-semibold text-foreground capitalize">
            {sidebarItems.find(s => s.id === activeSection)?.label || activeSection}
          </h2>
          <div className="flex items-center gap-3">
            <Input placeholder="Search..." className="w-48 h-9 rounded-sm font-body text-sm" />
            <div className="w-8 h-8 rounded-full bg-secondary flex items-center justify-center">
              <span className="font-body text-xs font-semibold text-foreground">A</span>
            </div>
          </div>
        </header>

        <div className="p-6 lg:p-8">
          <motion.div
            key={activeSection}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
          >
            {ActiveComponent && <ActiveComponent />}
          </motion.div>
        </div>
      </main>
    </div>
  );
};

export default Admin;

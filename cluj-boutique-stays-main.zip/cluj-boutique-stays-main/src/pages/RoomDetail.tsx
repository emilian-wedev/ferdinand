import { useState } from "react";
import { useParams, Link } from "react-router-dom";
import { motion } from "framer-motion";
import { ChevronLeft, ChevronRight, Users, Maximize, Bath, Star, ArrowRight, Check, MapPin } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import BookingSearchBar from "@/components/booking/BookingSearchBar";
import RoomCard from "@/components/booking/RoomCard";
import { getRoomBySlug, rooms, BOOKING_URL } from "@/lib/roomData";

const RoomDetail = () => {
  const { slug } = useParams<{ slug: string }>();
  const room = getRoomBySlug(slug || "");
  const [currentImage, setCurrentImage] = useState(0);

  if (!room) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="pt-32 pb-24 text-center container mx-auto px-4">
          <h1 className="font-display text-3xl font-semibold text-foreground mb-4">Room Not Found</h1>
          <Link to="/booking" className="font-body text-primary hover:underline">Browse all rooms</Link>
        </div>
        <Footer />
      </div>
    );
  }

  const otherRooms = rooms.filter((r) => r.id !== room.id);
  const nextImage = () => setCurrentImage((c) => (c + 1) % room.images.length);
  const prevImage = () => setCurrentImage((c) => (c - 1 + room.images.length) % room.images.length);

  return (
    <div className="min-h-screen bg-background">
      <Header />

      {/* Breadcrumb */}
      <div className="pt-24 lg:pt-28 bg-bone">
        <div className="container mx-auto px-4 py-4">
          <nav className="font-body text-sm text-muted-foreground">
            <Link to="/" className="hover:text-foreground transition-colors">Home</Link>
            <span className="mx-2">/</span>
            <Link to="/booking" className="hover:text-foreground transition-colors">Rooms</Link>
            <span className="mx-2">/</span>
            <span className="text-foreground">{room.name}</span>
          </nav>
        </div>
      </div>

      {/* Title + Location */}
      <section className="bg-bone pb-6">
        <div className="container mx-auto px-4">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
            <h1 className="font-display text-3xl md:text-4xl lg:text-5xl font-semibold text-foreground mb-2">{room.name}</h1>
            <div className="flex flex-wrap items-center gap-4 font-body text-sm text-muted-foreground">
              <span className="uppercase tracking-wider text-xs">
                Max {room.guests} {room.guests === 1 ? "guest" : "guests"} | {room.beds} | {room.bathrooms} bathroom
              </span>
              <span className="flex items-center gap-1 text-primary"><MapPin size={14} /> Regele Ferdinand nr 10, Cluj-Napoca</span>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Gallery */}
      <section className="bg-bone pb-8">
        <div className="container mx-auto px-4">
          <div className="relative overflow-hidden rounded-sm aspect-[16/9] lg:aspect-[21/9] shadow-elevated">
            <motion.img
              key={currentImage}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.4 }}
              src={room.images[currentImage]}
              alt={`${room.name} - photo ${currentImage + 1}`}
              className="w-full h-full object-cover"
            />
            <button onClick={prevImage} className="absolute left-4 top-1/2 -translate-y-1/2 w-12 h-12 rounded-full bg-card/80 backdrop-blur-sm flex items-center justify-center hover:bg-card transition-colors shadow-soft">
              <ChevronLeft size={20} />
            </button>
            <button onClick={nextImage} className="absolute right-4 top-1/2 -translate-y-1/2 w-12 h-12 rounded-full bg-card/80 backdrop-blur-sm flex items-center justify-center hover:bg-card transition-colors shadow-soft">
              <ChevronRight size={20} />
            </button>
            <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2">
              {room.images.map((_, i) => (
                <button
                  key={i}
                  onClick={() => setCurrentImage(i)}
                  className={`w-2.5 h-2.5 rounded-full transition-colors ${i === currentImage ? "bg-primary" : "bg-card/60"}`}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Content + Booking Sidebar */}
      <section className="py-12 lg:py-16">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-3 gap-12">
            {/* Left - Details */}
            <div className="lg:col-span-2 space-y-12">
              {/* Description */}
              <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
                <h2 className="font-display text-2xl font-semibold text-foreground mb-4">About This Room</h2>
                <p className="font-body text-muted-foreground leading-relaxed">{room.description}</p>
              </motion.div>

              {/* Room Highlights */}
              <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
                <h2 className="font-display text-2xl font-semibold text-foreground mb-6">Room Highlights</h2>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  <div className="flex items-center gap-3 p-4 bg-secondary rounded-sm">
                    <Users className="text-primary" size={20} />
                    <div>
                      <p className="font-body text-sm font-medium text-foreground">{room.guestsLabel}</p>
                      <p className="font-body text-xs text-muted-foreground">Maximum capacity</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 p-4 bg-secondary rounded-sm">
                    <Maximize className="text-primary" size={20} />
                    <div>
                      <p className="font-body text-sm font-medium text-foreground">{room.size}</p>
                      <p className="font-body text-xs text-muted-foreground">Room size</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 p-4 bg-secondary rounded-sm">
                    <Bath className="text-primary" size={20} />
                    <div>
                      <p className="font-body text-sm font-medium text-foreground">{room.bathrooms} Bathroom</p>
                      <p className="font-body text-xs text-muted-foreground">Private ensuite</p>
                    </div>
                  </div>
                </div>
              </motion.div>

              {/* Amenities */}
              <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
                <h2 className="font-display text-2xl font-semibold text-foreground mb-6">Amenities</h2>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  {room.amenities.map((amenity) => (
                    <div key={amenity} className="flex items-center gap-2.5 font-body text-sm text-muted-foreground py-2">
                      <Check size={16} className="text-primary flex-shrink-0" />
                      {amenity}
                    </div>
                  ))}
                </div>
              </motion.div>

              {/* Policies */}
              <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
                <h2 className="font-display text-2xl font-semibold text-foreground mb-6">Policies</h2>
                <div className="space-y-3">
                  {room.policies.map((policy) => (
                    <div key={policy} className="flex items-center gap-2.5 font-body text-sm text-muted-foreground py-2 border-b border-border last:border-0">
                      <Check size={16} className="text-primary flex-shrink-0" />
                      {policy}
                    </div>
                  ))}
                </div>
              </motion.div>

              {/* Reviews */}
              <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}>
                <h2 className="font-display text-2xl font-semibold text-foreground mb-6">Guest Reviews</h2>
                <div className="space-y-6">
                  {[
                    { name: "Elena M.", rating: 5, text: "Beautiful room, spotless clean, and the location is unbeatable. Walking distance to everything in Cluj." },
                    { name: "Marco B.", rating: 5, text: "Modern design, comfortable bed, and very quiet despite being in the city center. Highly recommend." },
                  ].map((review, i) => (
                    <div key={i} className="p-6 bg-secondary rounded-sm">
                      <div className="flex items-center gap-1 mb-3">
                        {Array.from({ length: 5 }).map((_, j) => (
                          <Star key={j} size={14} className={j < review.rating ? "text-primary fill-primary" : "text-border"} />
                        ))}
                      </div>
                      <p className="font-body text-sm text-muted-foreground leading-relaxed mb-3">"{review.text}"</p>
                      <p className="font-body text-sm font-semibold text-foreground">{review.name}</p>
                    </div>
                  ))}
                </div>
              </motion.div>
            </div>

            {/* Right - Booking Sidebar */}
            <div className="lg:col-span-1">
              <div className="sticky top-28 space-y-6">
                <div className="bg-card border border-border rounded-sm p-6 shadow-card">
                  <div className="flex items-baseline gap-2 mb-6">
                    <span className="font-display text-3xl font-semibold text-foreground">€{room.priceFrom}</span>
                    <span className="font-body text-sm text-muted-foreground">/ night</span>
                  </div>
                  <BookingSearchBar variant="compact" className="border-0 shadow-none p-0" />
                </div>

                <a
                  href={BOOKING_URL}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="block w-full text-center px-6 py-4 bg-primary text-primary-foreground font-body text-base font-semibold rounded-sm hover:bg-gold-dark transition-colors"
                >
                  Book This Room
                </a>

                <div className="bg-secondary rounded-sm p-6">
                  <h3 className="font-display text-lg font-semibold text-foreground mb-3">Need Help?</h3>
                  <p className="font-body text-sm text-muted-foreground mb-4">Our team is happy to assist with your reservation.</p>
                  <a href="tel:+40740228899" className="block font-body text-sm text-primary hover:underline mb-2">0740 228 899</a>
                  <a
                    href="https://wa.me/40740228899"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="block font-body text-sm text-primary hover:underline"
                  >
                    WhatsApp Us
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Other Rooms */}
      <section className="py-16 lg:py-20 bg-bone">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <p className="font-body text-sm uppercase tracking-[0.2em] text-primary mb-3">Explore More</p>
            <h2 className="font-display text-3xl font-semibold text-foreground">Other Room Types</h2>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            {otherRooms.map((r, i) => (
              <RoomCard key={r.id} room={r} index={i} variant="grid" />
            ))}
          </div>
        </div>
      </section>

      {/* CTA Banner */}
      <section className="py-16 bg-foreground">
        <div className="container mx-auto px-4 text-center">
          <h2 className="font-display text-3xl md:text-4xl font-semibold text-background mb-4">Ready to Experience Cluj?</h2>
          <p className="font-body text-background/60 mb-8 max-w-lg mx-auto">Book your stay at Ferdinand Boutique and discover the city from its very heart.</p>
          <a
            href={BOOKING_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-8 py-4 bg-primary text-primary-foreground font-body text-base font-semibold rounded-sm hover:bg-gold-dark transition-colors"
          >
            Book Your Stay <ArrowRight size={16} />
          </a>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default RoomDetail;

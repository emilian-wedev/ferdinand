import { motion } from "framer-motion";
import { ArrowRight } from "lucide-react";
import roomDouble from "@/assets/room-double.jpg";
import roomApartment from "@/assets/room-apartment.jpg";
import roomTriple from "@/assets/room-triple.jpg";

const BOOKING_URL = "https://ferdinand-boutique.pynbooking.direct/";

const featured = [
  {
    name: "Double Room",
    tag: "Most Popular",
    image: roomDouble,
    blurb: "Perfect for couples. Elegant, spacious, and central.",
  },
  {
    name: "Apartment",
    tag: "Best for Families",
    image: roomApartment,
    blurb: "Hotel luxury with the freedom of a private apartment.",
  },
  {
    name: "Triple Room",
    tag: "Group Favorite",
    image: roomTriple,
    blurb: "Three beds, one unforgettable Cluj experience.",
  },
];

const FeaturedRooms = () => {
  return (
    <section className="py-24 lg:py-32 bg-bone">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <p className="font-body text-sm uppercase tracking-[0.2em] text-gold mb-4">Featured Stays</p>
          <h2 className="font-display text-3xl md:text-4xl lg:text-5xl font-semibold text-foreground">
            Our Guest Favorites
          </h2>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8">
          {featured.map((room, i) => (
            <motion.div
              key={room.name}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: i * 0.15 }}
              className="group relative overflow-hidden rounded-sm shadow-card hover:shadow-elevated transition-all duration-500"
            >
              <div className="relative aspect-[3/4] overflow-hidden">
                <img
                  src={room.image}
                  alt={`${room.name} - featured stay at Ferdinand Boutique`}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-charcoal/80 via-charcoal/20 to-transparent" />

                <div className="absolute top-4 left-4">
                  <span className="px-3 py-1 bg-primary text-primary-foreground font-body text-xs font-semibold uppercase tracking-wider rounded-sm">
                    {room.tag}
                  </span>
                </div>

                <div className="absolute bottom-0 left-0 right-0 p-6">
                  <h3 className="font-display text-2xl font-semibold text-primary-foreground mb-2">{room.name}</h3>
                  <p className="font-body text-sm text-primary-foreground/80 mb-4">{room.blurb}</p>
                  <a
                    href={BOOKING_URL}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 font-body text-sm font-semibold text-gold-light hover:text-gold transition-colors"
                  >
                    Book Now <ArrowRight size={16} />
                  </a>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeaturedRooms;

import { useState } from "react";
import { Plus, Edit, Trash2, GripVertical, Eye, EyeOff } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { rooms, RoomType } from "@/lib/roomData";
import { allAmenities } from "@/components/admin/amenitiesData";
import { toast } from "sonner";

interface RoomFormData {
  name: string;
  slug: string;
  category: string;
  guests: number;
  guestsLabel: string;
  beds: string;
  bathrooms: number;
  size: string;
  shortDescription: string;
  description: string;
  priceFrom: number;
  tag: string;
  active: boolean;
  displayOrder: number;
  externalMapping: string;
  selectedAmenities: string[];
  highlights: string;
}

const defaultForm: RoomFormData = {
  name: "", slug: "", category: "standard", guests: 2, guestsLabel: "2 guests",
  beds: "", bathrooms: 1, size: "", shortDescription: "", description: "",
  priceFrom: 0, tag: "", active: true, displayOrder: 0, externalMapping: "",
  selectedAmenities: [], highlights: "",
};

const formFromRoom = (r: RoomType): RoomFormData => ({
  name: r.name, slug: r.slug, category: "standard", guests: r.guests,
  guestsLabel: r.guestsLabel, beds: r.beds, bathrooms: r.bathrooms,
  size: r.size, shortDescription: r.shortDescription, description: r.description,
  priceFrom: r.priceFrom, tag: r.tag || "", active: true, displayOrder: 0,
  externalMapping: "", selectedAmenities: r.amenities, highlights: r.features.join(", "),
});

const AdminRooms = () => {
  const [editOpen, setEditOpen] = useState(false);
  const [editingRoom, setEditingRoom] = useState<RoomType | null>(null);
  const [form, setForm] = useState<RoomFormData>(defaultForm);

  const openEdit = (room: RoomType) => {
    setEditingRoom(room);
    setForm(formFromRoom(room));
    setEditOpen(true);
  };

  const openAdd = () => {
    setEditingRoom(null);
    setForm(defaultForm);
    setEditOpen(true);
  };

  const toggleAmenity = (a: string) => {
    setForm(prev => ({
      ...prev,
      selectedAmenities: prev.selectedAmenities.includes(a)
        ? prev.selectedAmenities.filter(x => x !== a)
        : [...prev.selectedAmenities, a],
    }));
  };

  const handleSave = () => {
    toast.success(editingRoom ? `${form.name} updated` : `${form.name} created`);
    setEditOpen(false);
  };

  const handleDelete = (room: RoomType) => {
    toast.success(`${room.name} removed`);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <p className="font-body text-sm text-muted-foreground">{rooms.length} room types configured</p>
        <Button onClick={openAdd} className="bg-primary text-primary-foreground hover:bg-primary/90 rounded-sm font-body gap-2">
          <Plus size={16} /> Add Room Type
        </Button>
      </div>

      <div className="space-y-3">
        {rooms.map((room, idx) => (
          <div key={room.id} className="bg-card border border-border rounded-sm p-4 flex flex-col md:flex-row md:items-center gap-4">
            <GripVertical size={16} className="text-muted-foreground cursor-grab hidden md:block" />
            <img src={room.images[0]} alt={room.name} className="w-20 h-14 object-cover rounded-sm flex-shrink-0" />
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <h3 className="font-display text-base font-semibold text-foreground">{room.name}</h3>
                {room.tag && <span className="font-body text-[10px] uppercase tracking-wider px-1.5 py-0.5 rounded-sm bg-primary/10 text-primary">{room.tag}</span>}
              </div>
              <p className="font-body text-xs text-muted-foreground mt-0.5">{room.guestsLabel} · {room.size} · {room.beds} · From €{room.priceFrom}/night</p>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm" className="rounded-sm gap-1 font-body" onClick={() => openEdit(room)}>
                <Edit size={14} /> Edit
              </Button>
              <Button variant="outline" size="sm" className="rounded-sm gap-1 font-body text-destructive hover:text-destructive" onClick={() => handleDelete(room)}>
                <Trash2 size={14} />
              </Button>
            </div>
          </div>
        ))}
      </div>

      {/* Edit / Add Sheet */}
      <Sheet open={editOpen} onOpenChange={setEditOpen}>
        <SheetContent className="w-full sm:max-w-xl overflow-y-auto">
          <SheetHeader>
            <SheetTitle className="font-display">{editingRoom ? `Edit: ${editingRoom.name}` : "Add Room Type"}</SheetTitle>
          </SheetHeader>

          <div className="space-y-5 mt-6">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="font-body text-sm">Room Name</Label>
                <Input value={form.name} onChange={e => setForm(p => ({ ...p, name: e.target.value }))} className="mt-1 rounded-sm" />
              </div>
              <div>
                <Label className="font-body text-sm">URL Slug</Label>
                <Input value={form.slug} onChange={e => setForm(p => ({ ...p, slug: e.target.value }))} className="mt-1 rounded-sm" />
              </div>
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div>
                <Label className="font-body text-sm">Category</Label>
                <Select value={form.category} onValueChange={v => setForm(p => ({ ...p, category: v }))}>
                  <SelectTrigger className="mt-1 rounded-sm"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="standard">Standard</SelectItem>
                    <SelectItem value="deluxe">Deluxe</SelectItem>
                    <SelectItem value="suite">Suite</SelectItem>
                    <SelectItem value="apartment">Apartment</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="font-body text-sm">Max Guests</Label>
                <Input type="number" value={form.guests} onChange={e => setForm(p => ({ ...p, guests: +e.target.value }))} className="mt-1 rounded-sm" />
              </div>
              <div>
                <Label className="font-body text-sm">Guests Label</Label>
                <Input value={form.guestsLabel} onChange={e => setForm(p => ({ ...p, guestsLabel: e.target.value }))} className="mt-1 rounded-sm" />
              </div>
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div>
                <Label className="font-body text-sm">Beds</Label>
                <Input value={form.beds} onChange={e => setForm(p => ({ ...p, beds: e.target.value }))} className="mt-1 rounded-sm" />
              </div>
              <div>
                <Label className="font-body text-sm">Bathrooms</Label>
                <Input type="number" value={form.bathrooms} onChange={e => setForm(p => ({ ...p, bathrooms: +e.target.value }))} className="mt-1 rounded-sm" />
              </div>
              <div>
                <Label className="font-body text-sm">Size</Label>
                <Input value={form.size} onChange={e => setForm(p => ({ ...p, size: e.target.value }))} className="mt-1 rounded-sm" />
              </div>
            </div>

            <div>
              <Label className="font-body text-sm">Short Description</Label>
              <Input value={form.shortDescription} onChange={e => setForm(p => ({ ...p, shortDescription: e.target.value }))} className="mt-1 rounded-sm" />
            </div>

            <div>
              <Label className="font-body text-sm">Full Description</Label>
              <textarea value={form.description} onChange={e => setForm(p => ({ ...p, description: e.target.value }))}
                className="mt-1 w-full h-28 rounded-sm border border-input bg-background px-3 py-2 font-body text-sm resize-none focus:outline-none focus:ring-2 focus:ring-ring" />
            </div>

            <div>
              <Label className="font-body text-sm">Highlights (comma-separated)</Label>
              <Input value={form.highlights} onChange={e => setForm(p => ({ ...p, highlights: e.target.value }))} className="mt-1 rounded-sm" />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="font-body text-sm">Price From (€)</Label>
                <Input type="number" value={form.priceFrom} onChange={e => setForm(p => ({ ...p, priceFrom: +e.target.value }))} className="mt-1 rounded-sm" />
              </div>
              <div>
                <Label className="font-body text-sm">Tag / Badge</Label>
                <Input value={form.tag} onChange={e => setForm(p => ({ ...p, tag: e.target.value }))} placeholder="e.g. Most Popular" className="mt-1 rounded-sm" />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="font-body text-sm">Display Order</Label>
                <Input type="number" value={form.displayOrder} onChange={e => setForm(p => ({ ...p, displayOrder: +e.target.value }))} className="mt-1 rounded-sm" />
              </div>
              <div>
                <Label className="font-body text-sm">External Mapping ID</Label>
                <Input value={form.externalMapping} onChange={e => setForm(p => ({ ...p, externalMapping: e.target.value }))} placeholder="Booking system ID" className="mt-1 rounded-sm" />
              </div>
            </div>

            <div className="flex items-center gap-3">
              <Switch checked={form.active} onCheckedChange={v => setForm(p => ({ ...p, active: v }))} />
              <Label className="font-body text-sm">Active / visible on website</Label>
            </div>

            {/* Amenities */}
            <div>
              <Label className="font-body text-sm mb-2 block">Amenities</Label>
              <div className="flex flex-wrap gap-2">
                {allAmenities.map(a => (
                  <button
                    key={a.id}
                    type="button"
                    onClick={() => toggleAmenity(a.title)}
                    className={`font-body text-xs px-2.5 py-1.5 rounded-sm border transition-colors ${
                      form.selectedAmenities.includes(a.title)
                        ? "bg-primary text-primary-foreground border-primary"
                        : "bg-background text-foreground border-border hover:border-primary/50"
                    }`}
                  >
                    {a.title}
                  </button>
                ))}
              </div>
            </div>

            {/* Photos placeholder */}
            <div>
              <Label className="font-body text-sm mb-2 block">Room Photos</Label>
              <div className="border-2 border-dashed border-border rounded-sm p-6 text-center">
                <p className="font-body text-sm text-muted-foreground">Drag & drop photos or click to upload.</p>
                <p className="font-body text-xs text-muted-foreground mt-1">Photos can also be assigned from the Media Library.</p>
              </div>
              {editingRoom && (
                <div className="flex gap-2 mt-3">
                  {editingRoom.images.map((img, i) => (
                    <img key={i} src={img} alt="" className="w-16 h-12 object-cover rounded-sm border border-border" />
                  ))}
                </div>
              )}
            </div>

            <div className="flex gap-3 pt-4 border-t border-border">
              <Button onClick={handleSave} className="bg-primary text-primary-foreground hover:bg-primary/90 rounded-sm font-body flex-1">
                {editingRoom ? "Save Changes" : "Create Room"}
              </Button>
              <Button variant="outline" onClick={() => setEditOpen(false)} className="rounded-sm font-body">Cancel</Button>
            </div>
          </div>
        </SheetContent>
      </Sheet>
    </div>
  );
};

export default AdminRooms;

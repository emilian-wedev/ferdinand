import { useState } from "react";
import { Plus, Edit, Search, Tag, Mail } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";

interface Guest {
  id: string;
  name: string;
  email: string;
  phone: string;
  stays: number;
  lastStay: string;
  source: string;
  tags: string[];
  notes: string;
  marketingConsent: boolean;
  status: "active" | "vip" | "inactive";
}

const initialGuests: Guest[] = [
  { id: "1", name: "Elena M.", email: "elena@example.com", phone: "+40712345678", stays: 3, lastStay: "2026-03-15", source: "Direct", tags: ["Returning", "Couples"], notes: "Prefers quiet room on upper floor.", marketingConsent: true, status: "vip" },
  { id: "2", name: "Marco B.", email: "marco@example.com", phone: "+39345678901", stays: 1, lastStay: "2026-03-12", source: "Booking.com", tags: ["Business"], notes: "", marketingConsent: false, status: "active" },
  { id: "3", name: "Sophie L.", email: "sophie@example.com", phone: "+33612345678", stays: 2, lastStay: "2026-02-28", source: "Direct", tags: ["Family"], notes: "Traveled with 2 children.", marketingConsent: true, status: "active" },
  { id: "4", name: "Ana T.", email: "ana@example.com", phone: "+40723456789", stays: 1, lastStay: "2026-03-20", source: "Airbnb", tags: [], notes: "", marketingConsent: true, status: "active" },
];

const AdminGuests = () => {
  const [guests, setGuests] = useState(initialGuests);
  const [search, setSearch] = useState("");
  const [editOpen, setEditOpen] = useState(false);
  const [editing, setEditing] = useState<Guest | null>(null);

  const filtered = guests.filter(g => g.name.toLowerCase().includes(search.toLowerCase()) || g.email.toLowerCase().includes(search.toLowerCase()));

  const openEdit = (g: Guest) => { setEditing({ ...g }); setEditOpen(true); };
  const openAdd = () => { setEditing({ id: "", name: "", email: "", phone: "", stays: 0, lastStay: "", source: "Direct", tags: [], notes: "", marketingConsent: false, status: "active" }); setEditOpen(true); };

  const save = () => {
    if (!editing) return;
    if (editing.id) {
      setGuests(prev => prev.map(g => g.id === editing.id ? editing : g));
      toast.success("Guest updated");
    } else {
      setGuests(prev => [...prev, { ...editing, id: Date.now().toString() }]);
      toast.success("Guest added");
    }
    setEditOpen(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="relative">
          <Search size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <Input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search guests..." className="pl-8 w-56 h-9 rounded-sm font-body text-sm" />
        </div>
        <Button onClick={openAdd} className="bg-primary text-primary-foreground hover:bg-primary/90 rounded-sm font-body gap-2">
          <Plus size={16} /> Add Guest
        </Button>
      </div>

      <div className="grid grid-cols-3 gap-3">
        <div className="bg-card border border-border rounded-sm p-4 text-center">
          <p className="font-body text-xs text-muted-foreground uppercase tracking-wider">Total Guests</p>
          <p className="font-display text-2xl font-semibold text-foreground">{guests.length}</p>
        </div>
        <div className="bg-card border border-border rounded-sm p-4 text-center">
          <p className="font-body text-xs text-muted-foreground uppercase tracking-wider">VIP</p>
          <p className="font-display text-2xl font-semibold text-primary">{guests.filter(g => g.status === "vip").length}</p>
        </div>
        <div className="bg-card border border-border rounded-sm p-4 text-center">
          <p className="font-body text-xs text-muted-foreground uppercase tracking-wider">Marketing Consent</p>
          <p className="font-display text-2xl font-semibold text-foreground">{guests.filter(g => g.marketingConsent).length}</p>
        </div>
      </div>

      <div className="space-y-2">
        {filtered.map(g => (
          <div key={g.id} className="bg-card border border-border rounded-sm p-4 flex items-center gap-4">
            <div className="w-10 h-10 rounded-full bg-secondary flex items-center justify-center flex-shrink-0">
              <span className="font-body text-sm font-semibold text-foreground">{g.name[0]}</span>
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <h3 className="font-body text-sm font-semibold text-foreground">{g.name}</h3>
                {g.status === "vip" && <span className="font-body text-[10px] uppercase tracking-wider px-1.5 py-0.5 rounded-sm bg-primary/10 text-primary">VIP</span>}
              </div>
              <p className="font-body text-xs text-muted-foreground">{g.email} · {g.phone}</p>
              <p className="font-body text-xs text-muted-foreground">{g.stays} stay{g.stays !== 1 ? "s" : ""} · Last: {g.lastStay} · Source: {g.source}</p>
              {g.tags.length > 0 && (
                <div className="flex gap-1 mt-1">{g.tags.map(t => <span key={t} className="font-body text-[10px] px-1.5 py-0.5 rounded-sm bg-muted text-muted-foreground">{t}</span>)}</div>
              )}
            </div>
            <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => openEdit(g)}><Edit size={14} /></Button>
          </div>
        ))}
      </div>

      <Sheet open={editOpen} onOpenChange={setEditOpen}>
        <SheetContent className="w-full sm:max-w-md overflow-y-auto">
          <SheetHeader><SheetTitle className="font-display">{editing?.id ? "Edit Guest" : "Add Guest"}</SheetTitle></SheetHeader>
          {editing && (
            <div className="space-y-4 mt-6">
              <div><Label className="font-body text-sm">Name</Label><Input value={editing.name} onChange={e => setEditing(p => p ? { ...p, name: e.target.value } : p)} className="mt-1 rounded-sm" /></div>
              <div className="grid grid-cols-2 gap-4">
                <div><Label className="font-body text-sm">Email</Label><Input value={editing.email} onChange={e => setEditing(p => p ? { ...p, email: e.target.value } : p)} className="mt-1 rounded-sm" /></div>
                <div><Label className="font-body text-sm">Phone</Label><Input value={editing.phone} onChange={e => setEditing(p => p ? { ...p, phone: e.target.value } : p)} className="mt-1 rounded-sm" /></div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="font-body text-sm">Source</Label>
                  <Select value={editing.source} onValueChange={v => setEditing(p => p ? { ...p, source: v } : p)}>
                    <SelectTrigger className="mt-1 rounded-sm"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Direct">Direct</SelectItem>
                      <SelectItem value="Booking.com">Booking.com</SelectItem>
                      <SelectItem value="Airbnb">Airbnb</SelectItem>
                      <SelectItem value="Expedia">Expedia</SelectItem>
                      <SelectItem value="Other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="font-body text-sm">Status</Label>
                  <Select value={editing.status} onValueChange={v => setEditing(p => p ? { ...p, status: v as Guest["status"] } : p)}>
                    <SelectTrigger className="mt-1 rounded-sm"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="active">Active</SelectItem>
                      <SelectItem value="vip">VIP</SelectItem>
                      <SelectItem value="inactive">Inactive</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div><Label className="font-body text-sm">Tags (comma-separated)</Label><Input value={editing.tags.join(", ")} onChange={e => setEditing(p => p ? { ...p, tags: e.target.value.split(",").map(t => t.trim()).filter(Boolean) } : p)} className="mt-1 rounded-sm" /></div>
              <div><Label className="font-body text-sm">Notes</Label><textarea value={editing.notes} onChange={e => setEditing(p => p ? { ...p, notes: e.target.value } : p)} className="mt-1 w-full h-20 rounded-sm border border-input bg-background px-3 py-2 font-body text-sm resize-none focus:outline-none focus:ring-2 focus:ring-ring" /></div>
              <div className="flex items-center gap-3"><Switch checked={editing.marketingConsent} onCheckedChange={v => setEditing(p => p ? { ...p, marketingConsent: v } : p)} /><Label className="font-body text-sm">Marketing consent</Label></div>
              <div className="flex gap-3 pt-4 border-t border-border">
                <Button onClick={save} className="bg-primary text-primary-foreground rounded-sm font-body flex-1">Save</Button>
                <Button variant="outline" onClick={() => setEditOpen(false)} className="rounded-sm font-body">Cancel</Button>
              </div>
            </div>
          )}
        </SheetContent>
      </Sheet>
    </div>
  );
};

export default AdminGuests;

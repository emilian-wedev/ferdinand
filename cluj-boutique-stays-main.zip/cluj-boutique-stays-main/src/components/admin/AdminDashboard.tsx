import { useState } from "react";
import { TrendingUp, TrendingDown, CalendarDays, BedDouble, Star, DollarSign, Users, BarChart3, Clock, MessageSquare } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { cn } from "@/lib/utils";
import { format } from "date-fns";

const timeFilters = [
  { value: "30d", label: "Last 30 days" },
  { value: "this-month", label: "This month" },
  { value: "90d", label: "Last 90 days" },
  { value: "next-30", label: "Next 30 days" },
  { value: "next-90", label: "Next 90 days" },
  { value: "next-6m", label: "Next 6 months" },
  { value: "next-12m", label: "Next 12 months" },
  { value: "custom", label: "Custom range" },
];

interface MetricCard {
  label: string;
  value: string;
  change?: string;
  trend?: "up" | "down" | "neutral";
  icon: React.ElementType;
}

const pastMetrics: MetricCard[] = [
  { label: "Total Bookings", value: "127", change: "+12% vs prev.", trend: "up", icon: CalendarDays },
  { label: "Monthly Revenue", value: "€8,420", change: "+18% vs prev.", trend: "up", icon: DollarSign },
  { label: "Avg. Booking Value", value: "€156", change: "+4%", trend: "up", icon: BarChart3 },
  { label: "Occupancy Rate", value: "74%", change: "-2% vs prev.", trend: "down", icon: BedDouble },
  { label: "Average Rating", value: "4.8", change: "Stable", trend: "neutral", icon: Star },
  { label: "Review Requests Sent", value: "89", change: "42 responded", trend: "neutral", icon: MessageSquare },
];

const futureMetrics: MetricCard[] = [
  { label: "Upcoming Stays", value: "34", icon: Users },
  { label: "Future Reservations", value: "52", icon: CalendarDays },
  { label: "Projected Revenue", value: "€12,680", icon: DollarSign },
  { label: "Projected Occupancy", value: "68%", icon: BedDouble },
];

const roomPerformance = [
  { name: "Double Room", bookings: 48, revenue: "€3,120", occupancy: "82%" },
  { name: "Apartment", bookings: 31, revenue: "€2,945", occupancy: "71%" },
  { name: "Triple Room", bookings: 28, revenue: "€1,540", occupancy: "69%" },
  { name: "Single Room", bookings: 20, revenue: "€810", occupancy: "64%" },
];

const upcomingStays = [
  { guest: "Maria C.", room: "Double Room", checkIn: "Mar 24", checkOut: "Mar 27", status: "Confirmed" },
  { guest: "Andrei P.", room: "Apartment", checkIn: "Mar 25", checkOut: "Mar 30", status: "Confirmed" },
  { guest: "Sophie L.", room: "Triple Room", checkIn: "Mar 26", checkOut: "Mar 28", status: "Pending" },
  { guest: "James W.", room: "Single Room", checkIn: "Mar 28", checkOut: "Mar 31", status: "Confirmed" },
];

const pendingReviews = [
  { guest: "Elena M.", stayDate: "Mar 15-18", status: "Request sent", daysAgo: 4 },
  { guest: "Marco B.", stayDate: "Mar 12-14", status: "Awaiting response", daysAgo: 8 },
  { guest: "Ana T.", stayDate: "Mar 10-13", status: "Review received — pending approval", daysAgo: 9 },
];

const AdminDashboard = () => {
  const [timeFilter, setTimeFilter] = useState("30d");
  const [customFrom, setCustomFrom] = useState<Date>();
  const [customTo, setCustomTo] = useState<Date>();

  const isFutureFilter = timeFilter.startsWith("next");

  return (
    <div className="space-y-8">
      {/* Time filter */}
      <div className="flex flex-wrap items-center gap-3">
        <span className="font-body text-sm text-muted-foreground">Period:</span>
        <Select value={timeFilter} onValueChange={setTimeFilter}>
          <SelectTrigger className="w-48 h-9 rounded-sm font-body text-sm">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {timeFilters.map((f) => (
              <SelectItem key={f.value} value={f.value} className="font-body text-sm">{f.label}</SelectItem>
            ))}
          </SelectContent>
        </Select>

        {timeFilter === "custom" && (
          <div className="flex items-center gap-2">
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="outline" size="sm" className="rounded-sm font-body text-sm gap-1">
                  <CalendarDays size={14} />
                  {customFrom ? format(customFrom, "MMM d, yyyy") : "From"}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar mode="single" selected={customFrom} onSelect={setCustomFrom} className={cn("p-3 pointer-events-auto")} />
              </PopoverContent>
            </Popover>
            <span className="text-muted-foreground text-sm">—</span>
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="outline" size="sm" className="rounded-sm font-body text-sm gap-1">
                  <CalendarDays size={14} />
                  {customTo ? format(customTo, "MMM d, yyyy") : "To"}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar mode="single" selected={customTo} onSelect={setCustomTo} className={cn("p-3 pointer-events-auto")} />
              </PopoverContent>
            </Popover>
          </div>
        )}
      </div>

      {/* Performance metrics */}
      <div>
        <h3 className="font-display text-base font-semibold text-foreground mb-3">
          {isFutureFilter ? "Projected Performance" : "Past Performance"}
        </h3>
        <div className="grid grid-cols-2 lg:grid-cols-3 gap-4">
          {(isFutureFilter ? futureMetrics : pastMetrics).map((m) => (
            <div key={m.label} className="bg-card border border-border rounded-sm p-5">
              <div className="flex items-start justify-between mb-2">
                <p className="font-body text-xs uppercase tracking-wider text-muted-foreground">{m.label}</p>
                <m.icon size={16} className="text-primary" />
              </div>
              <p className="font-display text-2xl font-semibold text-foreground">{m.value}</p>
              {m.change && (
                <div className="flex items-center gap-1 mt-1">
                  {m.trend === "up" && <TrendingUp size={12} className="text-green-600" />}
                  {m.trend === "down" && <TrendingDown size={12} className="text-destructive" />}
                  <p className={cn("font-body text-xs", m.trend === "up" ? "text-green-600" : m.trend === "down" ? "text-destructive" : "text-muted-foreground")}>{m.change}</p>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Room Type Performance */}
      <div className="bg-card border border-border rounded-sm p-6">
        <h3 className="font-display text-base font-semibold text-foreground mb-4">Room Type Performance</h3>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-border">
                <th className="text-left font-body text-xs uppercase tracking-wider text-muted-foreground pb-3">Room</th>
                <th className="text-right font-body text-xs uppercase tracking-wider text-muted-foreground pb-3">Bookings</th>
                <th className="text-right font-body text-xs uppercase tracking-wider text-muted-foreground pb-3">Revenue</th>
                <th className="text-right font-body text-xs uppercase tracking-wider text-muted-foreground pb-3">Occupancy</th>
              </tr>
            </thead>
            <tbody>
              {roomPerformance.map((r) => (
                <tr key={r.name} className="border-b border-border/50 last:border-0">
                  <td className="font-body text-sm text-foreground py-3">{r.name}</td>
                  <td className="font-body text-sm text-foreground py-3 text-right">{r.bookings}</td>
                  <td className="font-body text-sm text-foreground py-3 text-right">{r.revenue}</td>
                  <td className="font-body text-sm text-foreground py-3 text-right">{r.occupancy}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* Upcoming Stays */}
        <div className="bg-card border border-border rounded-sm p-6">
          <h3 className="font-display text-base font-semibold text-foreground mb-4">Upcoming Stays</h3>
          <div className="space-y-3">
            {upcomingStays.map((s, i) => (
              <div key={i} className="flex items-center justify-between py-2 border-b border-border/50 last:border-0">
                <div>
                  <p className="font-body text-sm font-medium text-foreground">{s.guest}</p>
                  <p className="font-body text-xs text-muted-foreground">{s.room} · {s.checkIn} → {s.checkOut}</p>
                </div>
                <span className={cn("font-body text-xs px-2 py-0.5 rounded-sm", s.status === "Confirmed" ? "bg-green-100 text-green-700" : "bg-yellow-100 text-yellow-700")}>{s.status}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Pending Reviews */}
        <div className="bg-card border border-border rounded-sm p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-display text-base font-semibold text-foreground">Review Pipeline</h3>
            <div className="flex gap-2">
              <span className="font-body text-xs px-2 py-0.5 rounded-sm bg-primary/10 text-primary">3 approved</span>
              <span className="font-body text-xs px-2 py-0.5 rounded-sm bg-yellow-100 text-yellow-700">1 pending</span>
              <span className="font-body text-xs px-2 py-0.5 rounded-sm bg-muted text-muted-foreground">0 hidden</span>
            </div>
          </div>
          <div className="space-y-3">
            {pendingReviews.map((r, i) => (
              <div key={i} className="flex items-center justify-between py-2 border-b border-border/50 last:border-0">
                <div>
                  <p className="font-body text-sm font-medium text-foreground">{r.guest}</p>
                  <p className="font-body text-xs text-muted-foreground">Stay: {r.stayDate} · {r.daysAgo}d ago</p>
                </div>
                <span className="font-body text-xs text-muted-foreground">{r.status}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;

import { useState } from "react";
import { Plus, Trash2, Eye, Tag, FolderOpen, Upload, GripVertical } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { rooms } from "@/lib/roomData";
import { toast } from "sonner";

const folders = ["All", "Homepage", "Rooms", "Amenities", "Gallery", "Reviews", "General"];

interface PhotoItem {
  id: string;
  src: string;
  label: string;
  folder: string;
  assignedTo: string;
}

const initialPhotos: PhotoItem[] = rooms.flatMap(r =>
  r.images.map((img, i) => ({ id: `${r.id}-${i}`, src: img, label: r.name, folder: "Rooms", assignedTo: r.name }))
);

const AdminPhotos = () => {
  const [photos, setPhotos] = useState<PhotoItem[]>(initialPhotos);
  const [activeFolder, setActiveFolder] = useState("All");
  const [previewOpen, setPreviewOpen] = useState(false);
  const [previewPhoto, setPreviewPhoto] = useState<PhotoItem | null>(null);
  const [editOpen, setEditOpen] = useState(false);
  const [editPhoto, setEditPhoto] = useState<PhotoItem | null>(null);

  const filtered = activeFolder === "All" ? photos : photos.filter(p => p.folder === activeFolder);

  const openPreview = (p: PhotoItem) => { setPreviewPhoto(p); setPreviewOpen(true); };
  const openEdit = (p: PhotoItem) => { setEditPhoto({ ...p }); setEditOpen(true); };
  const saveEdit = () => {
    if (!editPhoto) return;
    setPhotos(prev => prev.map(p => p.id === editPhoto.id ? editPhoto : p));
    toast.success("Photo updated");
    setEditOpen(false);
  };
  const deletePhoto = (id: string) => {
    setPhotos(prev => prev.filter(p => p.id !== id));
    toast.success("Photo removed");
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <p className="font-body text-sm text-muted-foreground">{photos.length} images in library</p>
        <Button className="bg-primary text-primary-foreground hover:bg-primary/90 rounded-sm font-body gap-2">
          <Upload size={16} /> Upload Photos
        </Button>
      </div>

      {/* Folder tabs */}
      <div className="flex flex-wrap gap-2">
        {folders.map(f => (
          <button key={f} onClick={() => setActiveFolder(f)}
            className={`font-body text-xs px-3 py-1.5 rounded-sm border transition-colors ${
              activeFolder === f ? "bg-primary text-primary-foreground border-primary" : "bg-background text-foreground border-border hover:border-primary/50"
            }`}>
            <FolderOpen size={12} className="inline mr-1" />{f}
          </button>
        ))}
      </div>

      {/* Upload area */}
      <div className="border-2 border-dashed border-border rounded-sm p-8 text-center">
        <Upload size={24} className="mx-auto text-muted-foreground mb-2" />
        <p className="font-body text-sm text-muted-foreground">Drag & drop images here or click to browse</p>
        <p className="font-body text-xs text-muted-foreground mt-1">JPG, PNG, WebP · Max 10MB per file</p>
      </div>

      {/* Photo grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-3">
        {filtered.map(p => (
          <div key={p.id} className="group relative rounded-sm overflow-hidden aspect-square border border-border">
            <img src={p.src} alt={p.label} className="w-full h-full object-cover" />
            <div className="absolute inset-0 bg-foreground/0 group-hover:bg-foreground/50 transition-colors flex items-center justify-center gap-1.5 opacity-0 group-hover:opacity-100">
              <Button size="icon" variant="secondary" className="rounded-sm h-7 w-7" onClick={() => openPreview(p)}><Eye size={13} /></Button>
              <Button size="icon" variant="secondary" className="rounded-sm h-7 w-7" onClick={() => openEdit(p)}><Tag size={13} /></Button>
              <Button size="icon" variant="secondary" className="rounded-sm h-7 w-7" onClick={() => deletePhoto(p.id)}><Trash2 size={13} /></Button>
            </div>
            <div className="absolute bottom-0 inset-x-0 bg-foreground/60 px-2 py-1">
              <p className="font-body text-[10px] text-background truncate">{p.label}</p>
              <p className="font-body text-[9px] text-background/70">{p.folder} · {p.assignedTo}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Preview dialog */}
      <Dialog open={previewOpen} onOpenChange={setPreviewOpen}>
        <DialogContent className="max-w-2xl">
          {previewPhoto && (
            <>
              <DialogHeader><DialogTitle className="font-display">{previewPhoto.label}</DialogTitle></DialogHeader>
              <img src={previewPhoto.src} alt={previewPhoto.label} className="w-full rounded-sm" />
              <div className="flex gap-4 font-body text-sm text-muted-foreground">
                <span>Folder: {previewPhoto.folder}</span>
                <span>Assigned to: {previewPhoto.assignedTo}</span>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>

      {/* Edit dialog */}
      <Dialog open={editOpen} onOpenChange={setEditOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle className="font-display">Edit Photo Details</DialogTitle></DialogHeader>
          {editPhoto && (
            <div className="space-y-4 mt-2">
              <img src={editPhoto.src} alt="" className="w-full h-40 object-cover rounded-sm" />
              <div>
                <Label className="font-body text-sm">Label</Label>
                <Input value={editPhoto.label} onChange={e => setEditPhoto(p => p ? { ...p, label: e.target.value } : p)} className="mt-1 rounded-sm" />
              </div>
              <div>
                <Label className="font-body text-sm">Folder</Label>
                <Select value={editPhoto.folder} onValueChange={v => setEditPhoto(p => p ? { ...p, folder: v } : p)}>
                  <SelectTrigger className="mt-1 rounded-sm"><SelectValue /></SelectTrigger>
                  <SelectContent>{folders.filter(f => f !== "All").map(f => <SelectItem key={f} value={f}>{f}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div>
                <Label className="font-body text-sm">Assigned To</Label>
                <Select value={editPhoto.assignedTo} onValueChange={v => setEditPhoto(p => p ? { ...p, assignedTo: v } : p)}>
                  <SelectTrigger className="mt-1 rounded-sm"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Homepage">Homepage</SelectItem>
                    <SelectItem value="Gallery">Gallery</SelectItem>
                    {rooms.map(r => <SelectItem key={r.id} value={r.name}>{r.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="flex gap-3 pt-2">
                <Button onClick={saveEdit} className="bg-primary text-primary-foreground rounded-sm font-body flex-1">Save</Button>
                <Button variant="outline" onClick={() => setEditOpen(false)} className="rounded-sm font-body">Cancel</Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default AdminPhotos;

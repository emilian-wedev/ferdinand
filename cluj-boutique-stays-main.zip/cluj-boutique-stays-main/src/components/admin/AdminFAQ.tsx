import { useState } from "react";
import { Plus, Edit, Trash2, GripVertical, Eye, EyeOff } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";

interface FAQItem {
  id: string;
  question: string;
  answer: string;
  category: string;
  active: boolean;
  order: number;
}

const categories = ["General", "Check-in / Check-out", "Rooms & Amenities", "Policies", "Location", "Booking"];

const initialFAQs: FAQItem[] = [
  { id: "1", question: "What time is check-in and check-out?", answer: "Check-in is from 15:00, and check-out is until 11:00. Early check-in or late check-out may be available upon request.", category: "Check-in / Check-out", active: true, order: 1 },
  { id: "2", question: "Is Wi-Fi available?", answer: "Yes, complimentary high-speed Wi-Fi is available throughout the hotel.", category: "Rooms & Amenities", active: true, order: 2 },
  { id: "3", question: "Are family rooms available?", answer: "Yes, our Apartment accommodates up to 4 guests and is ideal for families, with a living area and kitchenette.", category: "Rooms & Amenities", active: true, order: 3 },
  { id: "4", question: "Is the hotel non-smoking?", answer: "Yes, Ferdinand Boutique is entirely non-smoking. Smoking is not permitted in any of the rooms or common areas.", category: "Policies", active: true, order: 4 },
  { id: "5", question: "Is there elevator access?", answer: "Yes, the building has an elevator for convenient access to all floors.", category: "General", active: true, order: 5 },
  { id: "6", question: "How do I book?", answer: "You can book directly through our website using the Book Now button, which connects to our reservation system.", category: "Booking", active: true, order: 6 },
  { id: "7", question: "What is the cancellation policy?", answer: "Free cancellation is available up to 48 hours before your scheduled arrival. Cancellations within 48 hours may incur a charge equivalent to the first night.", category: "Policies", active: true, order: 7 },
];

const AdminFAQ = () => {
  const [faqs, setFaqs] = useState(initialFAQs);
  const [filterCat, setFilterCat] = useState("All");
  const [editOpen, setEditOpen] = useState(false);
  const [editing, setEditing] = useState<FAQItem | null>(null);

  const filtered = filterCat === "All" ? faqs : faqs.filter(f => f.category === filterCat);

  const openEdit = (f: FAQItem) => { setEditing({ ...f }); setEditOpen(true); };
  const openAdd = () => { setEditing({ id: "", question: "", answer: "", category: categories[0], active: true, order: faqs.length + 1 }); setEditOpen(true); };

  const save = () => {
    if (!editing) return;
    if (editing.id) {
      setFaqs(prev => prev.map(f => f.id === editing.id ? editing : f));
      toast.success("FAQ updated");
    } else {
      setFaqs(prev => [...prev, { ...editing, id: Date.now().toString() }]);
      toast.success("FAQ added");
    }
    setEditOpen(false);
  };

  const remove = (id: string) => { setFaqs(prev => prev.filter(f => f.id !== id)); toast.success("FAQ deleted"); };
  const toggleActive = (id: string) => { setFaqs(prev => prev.map(f => f.id === id ? { ...f, active: !f.active } : f)); };

  const moveUp = (id: string) => {
    const idx = faqs.findIndex(f => f.id === id);
    if (idx <= 0) return;
    const next = [...faqs];
    [next[idx - 1], next[idx]] = [next[idx], next[idx - 1]];
    setFaqs(next.map((f, i) => ({ ...f, order: i + 1 })));
  };

  const moveDown = (id: string) => {
    const idx = faqs.findIndex(f => f.id === id);
    if (idx >= faqs.length - 1) return;
    const next = [...faqs];
    [next[idx], next[idx + 1]] = [next[idx + 1], next[idx]];
    setFaqs(next.map((f, i) => ({ ...f, order: i + 1 })));
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Select value={filterCat} onValueChange={setFilterCat}>
            <SelectTrigger className="w-44 h-9 rounded-sm font-body text-sm"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="All">All Categories</SelectItem>
              {categories.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
            </SelectContent>
          </Select>
          <p className="font-body text-xs text-muted-foreground">{filtered.length} FAQ items</p>
        </div>
        <Button onClick={openAdd} className="bg-primary text-primary-foreground hover:bg-primary/90 rounded-sm font-body gap-2">
          <Plus size={16} /> Add FAQ
        </Button>
      </div>

      <div className="space-y-2">
        {filtered.sort((a, b) => a.order - b.order).map(f => (
          <div key={f.id} className={`bg-card border border-border rounded-sm p-4 flex items-start gap-3 ${!f.active ? "opacity-50" : ""}`}>
            <div className="flex flex-col gap-0.5 flex-shrink-0 pt-1">
              <button onClick={() => moveUp(f.id)} className="text-muted-foreground hover:text-foreground text-xs leading-none">▲</button>
              <button onClick={() => moveDown(f.id)} className="text-muted-foreground hover:text-foreground text-xs leading-none">▼</button>
            </div>
            <div className="flex-1 min-w-0">
              <h4 className="font-body text-sm font-medium text-foreground">{f.question}</h4>
              <p className="font-body text-xs text-muted-foreground mt-1 line-clamp-2">{f.answer}</p>
              <span className="font-body text-[10px] uppercase tracking-wider text-muted-foreground">{f.category}</span>
            </div>
            <div className="flex items-center gap-1 flex-shrink-0">
              <Switch checked={f.active} onCheckedChange={() => toggleActive(f.id)} className="scale-75" />
              <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => openEdit(f)}><Edit size={13} /></Button>
              <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive" onClick={() => remove(f.id)}><Trash2 size={13} /></Button>
            </div>
          </div>
        ))}
      </div>

      <Dialog open={editOpen} onOpenChange={setEditOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle className="font-display">{editing?.id ? "Edit FAQ" : "Add FAQ"}</DialogTitle></DialogHeader>
          {editing && (
            <div className="space-y-4 mt-2">
              <div><Label className="font-body text-sm">Question</Label><Input value={editing.question} onChange={e => setEditing(p => p ? { ...p, question: e.target.value } : p)} className="mt-1 rounded-sm" /></div>
              <div><Label className="font-body text-sm">Answer</Label><textarea value={editing.answer} onChange={e => setEditing(p => p ? { ...p, answer: e.target.value } : p)} className="mt-1 w-full h-28 rounded-sm border border-input bg-background px-3 py-2 font-body text-sm resize-none focus:outline-none focus:ring-2 focus:ring-ring" /></div>
              <div>
                <Label className="font-body text-sm">Category</Label>
                <Select value={editing.category} onValueChange={v => setEditing(p => p ? { ...p, category: v } : p)}>
                  <SelectTrigger className="mt-1 rounded-sm"><SelectValue /></SelectTrigger>
                  <SelectContent>{categories.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="flex items-center gap-3"><Switch checked={editing.active} onCheckedChange={v => setEditing(p => p ? { ...p, active: v } : p)} /><Label className="font-body text-sm">Active</Label></div>
              <div className="flex gap-3 pt-2">
                <Button onClick={save} className="bg-primary text-primary-foreground rounded-sm font-body flex-1">Save</Button>
                <Button variant="outline" onClick={() => setEditOpen(false)} className="rounded-sm font-body">Cancel</Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default AdminFAQ;

import { useState } from "react";
import { Edit, Save, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { toast } from "sonner";

interface SectionData {
  id: string;
  title: string;
  lastUpdated: string;
  fields: { key: string; label: string; type: "text" | "textarea" | "url"; value: string }[];
}

const initialSections: SectionData[] = [
  {
    id: "hero", title: "Hero Section", lastUpdated: "March 2026",
    fields: [
      { key: "headline", label: "Headline", type: "text", value: "Boutique Rooms in the Heart of Cluj-Napoca" },
      { key: "subheadline", label: "Subheadline", type: "textarea", value: "Stay Central. Stay Stylish. Less commute. More Cluj." },
      { key: "ctaText", label: "Primary CTA Text", type: "text", value: "Book Your Stay" },
      { key: "ctaLink", label: "Primary CTA Link", type: "url", value: "https://ferdinand-boutique.pynbooking.direct/" },
      { key: "secondaryCta", label: "Secondary CTA Text", type: "text", value: "Explore Rooms" },
    ],
  },
  {
    id: "about", title: "About Section", lastUpdated: "March 2026",
    fields: [
      { key: "title", label: "Section Title", type: "text", value: "Welcome to Ferdinand Boutique" },
      { key: "highlight", label: "Highlighted Text", type: "text", value: "Your home in the heart of Cluj" },
      { key: "paragraph1", label: "Paragraph 1", type: "textarea", value: "Ferdinand Boutique is a premium boutique hotel on Regele Ferdinand, steps from Unirii Square, Saint Michael's Church, and the best cafes in Cluj." },
      { key: "paragraph2", label: "Paragraph 2", type: "textarea", value: "We welcome couples, solo travelers, families, and small groups looking for central, stylish accommodation." },
    ],
  },
  {
    id: "featured", title: "Featured Rooms", lastUpdated: "March 2026",
    fields: [
      { key: "title", label: "Section Title", type: "text", value: "Our Rooms" },
      { key: "subtitle", label: "Subtitle", type: "text", value: "Choose the room that fits your journey" },
    ],
  },
  {
    id: "whystay", title: "Why Stay With Us", lastUpdated: "March 2026",
    fields: [
      { key: "title", label: "Section Title", type: "text", value: "Why Ferdinand Boutique?" },
      { key: "subtitle", label: "Subtitle", type: "textarea", value: "Everything you need for a memorable Cluj experience." },
    ],
  },
  {
    id: "location", title: "Location", lastUpdated: "March 2026",
    fields: [
      { key: "title", label: "Section Title", type: "text", value: "In the Heart of Cluj-Napoca" },
      { key: "description", label: "Description", type: "textarea", value: "Steps from major landmarks, restaurants, and vibrant nightlife." },
      { key: "mapEmbed", label: "Google Maps Embed URL", type: "url", value: "" },
    ],
  },
  {
    id: "cta", title: "Call to Action", lastUpdated: "March 2026",
    fields: [
      { key: "title", label: "CTA Title", type: "text", value: "Ready to Experience Cluj?" },
      { key: "text", label: "CTA Text", type: "textarea", value: "Book your stay at Ferdinand Boutique and discover why our guests keep coming back." },
      { key: "buttonText", label: "Button Text", type: "text", value: "Book Now" },
      { key: "buttonLink", label: "Button Link", type: "url", value: "https://ferdinand-boutique.pynbooking.direct/" },
    ],
  },
];

const AdminHomepage = () => {
  const [sections, setSections] = useState(initialSections);
  const [editOpen, setEditOpen] = useState(false);
  const [editingSection, setEditingSection] = useState<SectionData | null>(null);

  const openEdit = (section: SectionData) => {
    setEditingSection(JSON.parse(JSON.stringify(section)));
    setEditOpen(true);
  };

  const updateField = (key: string, value: string) => {
    if (!editingSection) return;
    setEditingSection({
      ...editingSection,
      fields: editingSection.fields.map(f => f.key === key ? { ...f, value } : f),
    });
  };

  const saveSection = () => {
    if (!editingSection) return;
    setSections(prev => prev.map(s => s.id === editingSection.id ? { ...editingSection, lastUpdated: "Just now" } : s));
    toast.success(`${editingSection.title} updated`);
    setEditOpen(false);
  };

  return (
    <div className="space-y-6">
      <p className="font-body text-sm text-muted-foreground">Edit homepage section content. Changes will be reflected on the live website.</p>

      {sections.map(section => (
        <div key={section.id} className="bg-card border border-border rounded-sm p-5 flex items-center justify-between">
          <div>
            <h3 className="font-body text-sm font-semibold text-foreground">{section.title}</h3>
            <p className="font-body text-xs text-muted-foreground mt-0.5">
              {section.fields.length} fields · Last updated: {section.lastUpdated}
            </p>
          </div>
          <Button variant="outline" size="sm" className="rounded-sm gap-1 font-body" onClick={() => openEdit(section)}>
            <Edit size={14} /> Edit
          </Button>
        </div>
      ))}

      <Sheet open={editOpen} onOpenChange={setEditOpen}>
        <SheetContent className="w-full sm:max-w-lg overflow-y-auto">
          {editingSection && (
            <>
              <SheetHeader>
                <SheetTitle className="font-display">{editingSection.title}</SheetTitle>
              </SheetHeader>
              <div className="space-y-4 mt-6">
                {editingSection.fields.map(field => (
                  <div key={field.key}>
                    <Label className="font-body text-sm">{field.label}</Label>
                    {field.type === "textarea" ? (
                      <textarea
                        value={field.value}
                        onChange={e => updateField(field.key, e.target.value)}
                        className="mt-1 w-full h-24 rounded-sm border border-input bg-background px-3 py-2 font-body text-sm resize-none focus:outline-none focus:ring-2 focus:ring-ring"
                      />
                    ) : (
                      <Input
                        type={field.type === "url" ? "url" : "text"}
                        value={field.value}
                        onChange={e => updateField(field.key, e.target.value)}
                        className="mt-1 rounded-sm"
                      />
                    )}
                  </div>
                ))}
                <div className="flex gap-3 pt-4 border-t border-border">
                  <Button onClick={saveSection} className="bg-primary text-primary-foreground hover:bg-primary/90 rounded-sm font-body flex-1 gap-1">
                    <Save size={14} /> Save Changes
                  </Button>
                  <Button variant="outline" onClick={() => setEditOpen(false)} className="rounded-sm font-body">Cancel</Button>
                </div>
              </div>
            </>
          )}
        </SheetContent>
      </Sheet>
    </div>
  );
};

export default AdminHomepage;

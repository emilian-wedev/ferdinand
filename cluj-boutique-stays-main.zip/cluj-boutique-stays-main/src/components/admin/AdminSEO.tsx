import { useState } from "react";
import { Save, Globe, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { rooms } from "@/lib/roomData";
import { toast } from "sonner";

interface SEOData {
  title: string;
  metaDescription: string;
  slug: string;
  ogTitle: string;
  ogDescription: string;
  ogImage: string;
  canonical: string;
  indexable: boolean;
}

const defaultHomeSEO: SEOData = {
  title: "Ferdinand Boutique Cluj-Napoca | Boutique Hotel in the Heart of Cluj",
  metaDescription: "Stay at Ferdinand Boutique, a premium boutique hotel in central Cluj-Napoca. Modern rooms, prime location near Unirii Square.",
  slug: "/",
  ogTitle: "Ferdinand Boutique — Boutique Rooms in Cluj-Napoca",
  ogDescription: "Elegant boutique hotel in the heart of Cluj-Napoca. Walk to Unirii Square, Saint Michael's Church, and the best cafes.",
  ogImage: "",
  canonical: "https://ferdinandboutique.ro/",
  indexable: true,
};

const AdminSEO = () => {
  const [homeSEO, setHomeSEO] = useState(defaultHomeSEO);
  const [roomSEOs, setRoomSEOs] = useState<Record<string, SEOData>>(
    Object.fromEntries(rooms.map(r => [r.id, {
      title: `${r.name} | Ferdinand Boutique Cluj-Napoca`,
      metaDescription: r.shortDescription,
      slug: `/rooms/${r.slug}`,
      ogTitle: `${r.name} — Ferdinand Boutique`,
      ogDescription: r.shortDescription,
      ogImage: "",
      canonical: `https://ferdinandboutique.ro/rooms/${r.slug}`,
      indexable: true,
    }]))
  );

  const saveSEO = (label: string) => { toast.success(`${label} SEO saved`); };

  const SEOForm = ({ data, onChange, label }: { data: SEOData; onChange: (d: SEOData) => void; label: string }) => (
    <div className="space-y-4">
      <div>
        <Label className="font-body text-sm">Page Title</Label>
        <Input value={data.title} onChange={e => onChange({ ...data, title: e.target.value })} className="mt-1 rounded-sm" />
        <p className="font-body text-[10px] text-muted-foreground mt-1">{data.title.length}/60 characters</p>
      </div>
      <div>
        <Label className="font-body text-sm">Meta Description</Label>
        <textarea value={data.metaDescription} onChange={e => onChange({ ...data, metaDescription: e.target.value })}
          className="mt-1 w-full h-20 rounded-sm border border-input bg-background px-3 py-2 font-body text-sm resize-none focus:outline-none focus:ring-2 focus:ring-ring" />
        <p className="font-body text-[10px] text-muted-foreground mt-1">{data.metaDescription.length}/160 characters</p>
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div><Label className="font-body text-sm">URL Slug</Label><Input value={data.slug} onChange={e => onChange({ ...data, slug: e.target.value })} className="mt-1 rounded-sm" /></div>
        <div><Label className="font-body text-sm">Canonical URL</Label><Input value={data.canonical} onChange={e => onChange({ ...data, canonical: e.target.value })} className="mt-1 rounded-sm" /></div>
      </div>
      <div><Label className="font-body text-sm">OG Title</Label><Input value={data.ogTitle} onChange={e => onChange({ ...data, ogTitle: e.target.value })} className="mt-1 rounded-sm" /></div>
      <div><Label className="font-body text-sm">OG Description</Label><Input value={data.ogDescription} onChange={e => onChange({ ...data, ogDescription: e.target.value })} className="mt-1 rounded-sm" /></div>
      <div><Label className="font-body text-sm">OG Image URL</Label><Input value={data.ogImage} onChange={e => onChange({ ...data, ogImage: e.target.value })} className="mt-1 rounded-sm" placeholder="https://..." /></div>
      <div className="flex items-center gap-3">
        <Switch checked={data.indexable} onCheckedChange={v => onChange({ ...data, indexable: v })} />
        <Label className="font-body text-sm">Allow search engine indexing</Label>
      </div>
      <Button onClick={() => saveSEO(label)} className="bg-primary text-primary-foreground hover:bg-primary/90 rounded-sm font-body gap-1"><Save size={14} /> Save SEO</Button>
    </div>
  );

  return (
    <div className="space-y-6">
      <Tabs defaultValue="homepage">
        <TabsList className="mb-4">
          <TabsTrigger value="homepage" className="font-body text-sm">
            <Globe size={14} className="mr-1" /> Homepage
          </TabsTrigger>
          {rooms.map(r => (
            <TabsTrigger key={r.id} value={r.id} className="font-body text-sm">{r.name}</TabsTrigger>
          ))}
        </TabsList>

        <TabsContent value="homepage">
          <div className="bg-card border border-border rounded-sm p-6">
            <h3 className="font-display text-base font-semibold text-foreground mb-4">Homepage SEO</h3>
            <SEOForm data={homeSEO} onChange={setHomeSEO} label="Homepage" />
          </div>
        </TabsContent>

        {rooms.map(r => (
          <TabsContent key={r.id} value={r.id}>
            <div className="bg-card border border-border rounded-sm p-6">
              <h3 className="font-display text-base font-semibold text-foreground mb-4">{r.name} SEO</h3>
              <SEOForm data={roomSEOs[r.id]} onChange={d => setRoomSEOs(prev => ({ ...prev, [r.id]: d }))} label={r.name} />
            </div>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
};

export default AdminSEO;

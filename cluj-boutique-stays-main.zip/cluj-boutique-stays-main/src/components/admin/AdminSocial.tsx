import { useState } from "react";
import { Plus, Edit, Trash2, GripVertical, ExternalLink } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";

interface SocialProfile {
  id: string;
  platform: string;
  url: string;
  ctaLabel: string;
  displayOn: string;
  active: boolean;
  order: number;
}

const platforms = ["Instagram", "Facebook", "TikTok", "YouTube", "LinkedIn", "WhatsApp", "X / Twitter"];

const initialProfiles: SocialProfile[] = [
  { id: "1", platform: "Instagram", url: "https://instagram.com/ferdinandboutique", ctaLabel: "Follow us", displayOn: "Footer", active: true, order: 1 },
  { id: "2", platform: "Facebook", url: "https://facebook.com/ferdinandboutique", ctaLabel: "Like us", displayOn: "Footer", active: true, order: 2 },
  { id: "3", platform: "WhatsApp", url: "https://wa.me/40740228899", ctaLabel: "Message us", displayOn: "Footer, Contact", active: true, order: 3 },
  { id: "4", platform: "TikTok", url: "", ctaLabel: "Follow us", displayOn: "Footer", active: false, order: 4 },
];

const AdminSocial = () => {
  const [profiles, setProfiles] = useState(initialProfiles);
  const [editOpen, setEditOpen] = useState(false);
  const [editing, setEditing] = useState<SocialProfile | null>(null);

  const openEdit = (p: SocialProfile) => { setEditing({ ...p }); setEditOpen(true); };
  const openAdd = () => { setEditing({ id: "", platform: platforms[0], url: "", ctaLabel: "", displayOn: "Footer", active: true, order: profiles.length + 1 }); setEditOpen(true); };

  const save = () => {
    if (!editing) return;
    if (editing.id) {
      setProfiles(prev => prev.map(p => p.id === editing.id ? editing : p));
      toast.success(`${editing.platform} updated`);
    } else {
      setProfiles(prev => [...prev, { ...editing, id: Date.now().toString() }]);
      toast.success(`${editing.platform} added`);
    }
    setEditOpen(false);
  };

  const remove = (id: string) => { setProfiles(prev => prev.filter(p => p.id !== id)); toast.success("Profile removed"); };
  const toggleActive = (id: string) => { setProfiles(prev => prev.map(p => p.id === id ? { ...p, active: !p.active } : p)); };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <p className="font-body text-sm text-muted-foreground">Manage social media profiles displayed on the website</p>
        <Button onClick={openAdd} className="bg-primary text-primary-foreground hover:bg-primary/90 rounded-sm font-body gap-2">
          <Plus size={16} /> Add Profile
        </Button>
      </div>

      <div className="space-y-3">
        {profiles.sort((a, b) => a.order - b.order).map(p => (
          <div key={p.id} className={`bg-card border border-border rounded-sm p-5 flex items-center gap-4 ${!p.active ? "opacity-50" : ""}`}>
            <div className="w-10 h-10 rounded-sm bg-secondary flex items-center justify-center flex-shrink-0">
              <span className="font-body text-xs font-bold text-foreground">{p.platform[0]}</span>
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="font-body text-sm font-semibold text-foreground">{p.platform}</h3>
              <p className="font-body text-xs text-muted-foreground truncate">{p.url || "No URL set"}</p>
              <div className="flex gap-2 mt-1">
                <span className="font-body text-[10px] uppercase tracking-wider px-1.5 py-0.5 rounded-sm bg-muted text-muted-foreground">{p.displayOn}</span>
                {p.ctaLabel && <span className="font-body text-[10px] px-1.5 py-0.5 rounded-sm bg-primary/10 text-primary">CTA: {p.ctaLabel}</span>}
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Switch checked={p.active} onCheckedChange={() => toggleActive(p.id)} />
              {p.url && <a href={p.url} target="_blank" rel="noopener noreferrer"><Button variant="ghost" size="icon" className="h-8 w-8"><ExternalLink size={14} /></Button></a>}
              <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => openEdit(p)}><Edit size={14} /></Button>
              <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive" onClick={() => remove(p.id)}><Trash2 size={14} /></Button>
            </div>
          </div>
        ))}
      </div>

      <Dialog open={editOpen} onOpenChange={setEditOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle className="font-display">{editing?.id ? "Edit Profile" : "Add Social Profile"}</DialogTitle></DialogHeader>
          {editing && (
            <div className="space-y-4 mt-2">
              <div>
                <Label className="font-body text-sm">Platform</Label>
                <Select value={editing.platform} onValueChange={v => setEditing(p => p ? { ...p, platform: v } : p)}>
                  <SelectTrigger className="mt-1 rounded-sm"><SelectValue /></SelectTrigger>
                  <SelectContent>{platforms.map(p => <SelectItem key={p} value={p}>{p}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div><Label className="font-body text-sm">Profile URL</Label><Input value={editing.url} onChange={e => setEditing(p => p ? { ...p, url: e.target.value } : p)} className="mt-1 rounded-sm" placeholder="https://..." /></div>
              <div><Label className="font-body text-sm">CTA / Button Label</Label><Input value={editing.ctaLabel} onChange={e => setEditing(p => p ? { ...p, ctaLabel: e.target.value } : p)} className="mt-1 rounded-sm" placeholder="Follow us" /></div>
              <div><Label className="font-body text-sm">Display On</Label><Input value={editing.displayOn} onChange={e => setEditing(p => p ? { ...p, displayOn: e.target.value } : p)} className="mt-1 rounded-sm" placeholder="Footer, Contact, Header" /></div>
              <div className="flex items-center gap-3"><Switch checked={editing.active} onCheckedChange={v => setEditing(p => p ? { ...p, active: v } : p)} /><Label className="font-body text-sm">Active</Label></div>
              <div className="flex gap-3 pt-2">
                <Button onClick={save} className="bg-primary text-primary-foreground rounded-sm font-body flex-1">Save</Button>
                <Button variant="outline" onClick={() => setEditOpen(false)} className="rounded-sm font-body">Cancel</Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default AdminSocial;

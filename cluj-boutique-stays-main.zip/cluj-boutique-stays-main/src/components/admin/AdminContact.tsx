import { useState } from "react";
import { Save, Mail, Phone, MapPin, Clock, MessageSquare } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";

interface ContactInfo {
  hotelName: string;
  address: string;
  phone: string;
  email: string;
  whatsapp: string;
  mapEmbed: string;
  receptionPhone: string;
  businessHours: string;
}

interface Inquiry {
  id: string;
  name: string;
  email: string;
  subject: string;
  message: string;
  date: string;
  read: boolean;
}

const initialContact: ContactInfo = {
  hotelName: "Ferdinand Boutique Cluj-Napoca",
  address: "Regele Ferdinand nr 10, Cluj-Napoca, Județul Cluj",
  phone: "0740228899",
  email: "info@ferdinandboutique.ro",
  whatsapp: "+40740228899",
  mapEmbed: "",
  receptionPhone: "0740228899",
  businessHours: "24/7 — Self check-in available",
};

const initialInquiries: Inquiry[] = [
  { id: "1", name: "Maria C.", email: "maria@example.com", subject: "Group booking inquiry", message: "Hi, we are a group of 6 looking to book for April 15-18. What options do you have?", date: "2026-03-20", read: false },
  { id: "2", name: "David R.", email: "david@example.com", subject: "Parking availability", message: "Is there parking near the hotel? We are driving from Bucharest.", date: "2026-03-18", read: true },
  { id: "3", name: "Laura S.", email: "laura@example.com", subject: "Early check-in request", message: "Our flight arrives at 10am. Would early check-in be possible?", date: "2026-03-16", read: true },
];

const AdminContact = () => {
  const [info, setInfo] = useState(initialContact);
  const [inquiries, setInquiries] = useState(initialInquiries);

  const saveInfo = () => { toast.success("Contact information saved"); };
  const markRead = (id: string) => { setInquiries(prev => prev.map(q => q.id === id ? { ...q, read: true } : q)); };

  const unread = inquiries.filter(q => !q.read).length;

  return (
    <div className="space-y-8">
      {/* Business Contact Info */}
      <div className="bg-card border border-border rounded-sm p-6">
        <h3 className="font-display text-base font-semibold text-foreground mb-4">Business Contact Details</h3>
        <div className="space-y-4">
          <div className="grid md:grid-cols-2 gap-4">
            <div><Label className="font-body text-sm">Hotel Name</Label><Input value={info.hotelName} onChange={e => setInfo(p => ({ ...p, hotelName: e.target.value }))} className="mt-1 rounded-sm" /></div>
            <div><Label className="font-body text-sm">Email</Label><Input value={info.email} onChange={e => setInfo(p => ({ ...p, email: e.target.value }))} className="mt-1 rounded-sm" /></div>
          </div>
          <div><Label className="font-body text-sm">Address</Label><Input value={info.address} onChange={e => setInfo(p => ({ ...p, address: e.target.value }))} className="mt-1 rounded-sm" /></div>
          <div className="grid md:grid-cols-3 gap-4">
            <div><Label className="font-body text-sm">Phone</Label><Input value={info.phone} onChange={e => setInfo(p => ({ ...p, phone: e.target.value }))} className="mt-1 rounded-sm" /></div>
            <div><Label className="font-body text-sm">WhatsApp</Label><Input value={info.whatsapp} onChange={e => setInfo(p => ({ ...p, whatsapp: e.target.value }))} className="mt-1 rounded-sm" /></div>
            <div><Label className="font-body text-sm">Reception / Emergency</Label><Input value={info.receptionPhone} onChange={e => setInfo(p => ({ ...p, receptionPhone: e.target.value }))} className="mt-1 rounded-sm" /></div>
          </div>
          <div><Label className="font-body text-sm">Business Hours</Label><Input value={info.businessHours} onChange={e => setInfo(p => ({ ...p, businessHours: e.target.value }))} className="mt-1 rounded-sm" /></div>
          <div><Label className="font-body text-sm">Google Maps Embed URL</Label><Input value={info.mapEmbed} onChange={e => setInfo(p => ({ ...p, mapEmbed: e.target.value }))} className="mt-1 rounded-sm" placeholder="https://maps.google.com/..." /></div>
          <Button onClick={saveInfo} className="bg-primary text-primary-foreground hover:bg-primary/90 rounded-sm font-body gap-1"><Save size={14} /> Save Contact Info</Button>
        </div>
      </div>

      {/* Inquiries */}
      <div className="bg-card border border-border rounded-sm p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-display text-base font-semibold text-foreground">
            Contact Form Submissions
            {unread > 0 && <span className="ml-2 font-body text-xs px-2 py-0.5 rounded-sm bg-primary/10 text-primary">{unread} unread</span>}
          </h3>
        </div>

        {inquiries.length === 0 ? (
          <p className="font-body text-sm text-muted-foreground">No inquiries yet.</p>
        ) : (
          <div className="space-y-3">
            {inquiries.map(q => (
              <div key={q.id} className={`border border-border rounded-sm p-4 ${!q.read ? "bg-primary/5 border-primary/20" : ""}`}>
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <h4 className="font-body text-sm font-semibold text-foreground">{q.subject}</h4>
                    <p className="font-body text-xs text-muted-foreground">{q.name} · {q.email} · {q.date}</p>
                  </div>
                  {!q.read && (
                    <Button variant="ghost" size="sm" className="rounded-sm font-body text-xs" onClick={() => markRead(q.id)}>Mark read</Button>
                  )}
                </div>
                <p className="font-body text-sm text-muted-foreground">{q.message}</p>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default AdminContact;

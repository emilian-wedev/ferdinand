import { Wifi, Wind, Coffee, Car, Bath, CookingPot, Wine, Tv, Laptop, Users, Shirt, Snowflake, Lock, Waves, Dumbbell, Cigarette, Accessibility, Sparkles, Phone, ShieldCheck, BedDouble, Lamp, Fan } from "lucide-react";

export interface AmenityItem {
  id: string;
  title: string;
  description: string;
  category: string;
  icon: string; // lucide icon name
  active: boolean;
}

export const amenityIcons: Record<string, React.ElementType> = {
  wifi: Wifi, wind: Wind, coffee: Coffee, car: Car, bath: Bath,
  kitchen: CookingPot, minibar: Wine, tv: Tv, workspace: Laptop,
  family: Users, laundry: Shirt, ac: Snowflake, safe: Lock,
  pool: Waves, gym: Dumbbell, nosmoking: Cigarette, elevator: Accessibility,
  cleaning: Sparkles, phone: Phone, security: ShieldCheck, bed: BedDouble,
  lamp: Lamp, fan: Fan,
};

export const allAmenities: AmenityItem[] = [
  { id: "wifi", title: "Free Wi-Fi", description: "High-speed wireless internet", category: "Connectivity", icon: "wifi", active: true },
  { id: "ac", title: "Air Conditioning", description: "Individual climate control", category: "Comfort", icon: "ac", active: true },
  { id: "tv", title: "Smart TV", description: "Flat screen with streaming", category: "Entertainment", icon: "tv", active: true },
  { id: "bath", title: "Private Bathroom", description: "Ensuite with shower or bathtub", category: "Essentials", icon: "bath", active: true },
  { id: "kitchen", title: "Kitchenette", description: "Basic cooking facilities", category: "Self-catering", icon: "kitchen", active: true },
  { id: "minibar", title: "Mini Fridge", description: "Compact refrigerator", category: "Comfort", icon: "minibar", active: true },
  { id: "workspace", title: "Work Desk", description: "Dedicated workspace area", category: "Business", icon: "workspace", active: true },
  { id: "safe", title: "In-Room Safe", description: "Secure storage for valuables", category: "Security", icon: "safe", active: true },
  { id: "coffee", title: "Coffee / Tea", description: "Complimentary tea & coffee", category: "Comfort", icon: "coffee", active: true },
  { id: "car", title: "Parking", description: "On-site or nearby parking", category: "Transport", icon: "car", active: true },
  { id: "elevator", title: "Elevator Access", description: "Building elevator available", category: "Accessibility", icon: "elevator", active: true },
  { id: "nosmoking", title: "Non-Smoking", description: "Smoke-free environment", category: "Policy", icon: "nosmoking", active: true },
  { id: "family", title: "Family Friendly", description: "Suitable for children", category: "Guest Type", icon: "family", active: true },
  { id: "cleaning", title: "Daily Housekeeping", description: "Regular room cleaning", category: "Service", icon: "cleaning", active: true },
  { id: "laundry", title: "Iron & Ironing Board", description: "In-room laundry essentials", category: "Comfort", icon: "laundry", active: true },
  { id: "bed", title: "Premium Linens", description: "High-quality bed linens", category: "Comfort", icon: "bed", active: true },
  { id: "lamp", title: "Blackout Curtains", description: "Full room darkening", category: "Comfort", icon: "lamp", active: true },
  { id: "fan", title: "Hair Dryer", description: "In-bathroom hair dryer", category: "Essentials", icon: "fan", active: true },
  { id: "security", title: "24h Reception", description: "Round-the-clock assistance", category: "Service", icon: "security", active: true },
  { id: "phone", title: "Toiletries", description: "Complimentary bathroom amenities", category: "Essentials", icon: "phone", active: true },
];

export const amenityCategories = [...new Set(allAmenities.map(a => a.category))];

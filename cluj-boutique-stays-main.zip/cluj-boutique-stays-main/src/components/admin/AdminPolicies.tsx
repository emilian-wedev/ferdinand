import { useState } from "react";
import { Edit, Save } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { toast } from "sonner";

interface Policy {
  id: string;
  title: string;
  content: string;
  lastUpdated: string;
}

const initialPolicies: Policy[] = [
  { id: "checkin", title: "Check-in Policy", content: "Check-in is available from 15:00. Self check-in is available with keypad access. If you need early check-in, please contact us in advance to check availability. A valid government-issued photo ID is required at check-in.", lastUpdated: "March 2026" },
  { id: "checkout", title: "Check-out Policy", content: "Check-out is by 11:00. Late check-out may be available upon request, subject to availability and a surcharge. Please leave the room key at the reception desk or in the designated drop-off.", lastUpdated: "March 2026" },
  { id: "cancellation", title: "Cancellation Policy", content: "Free cancellation is available up to 48 hours before your scheduled arrival date. Cancellations made within 48 hours of arrival, or no-shows, will incur a charge equivalent to the first night of the reservation.", lastUpdated: "March 2026" },
  { id: "payment", title: "Payment Policy", content: "We accept major credit and debit cards (Visa, Mastercard). Payment is required at the time of booking or upon arrival, depending on the rate selected. A pre-authorization hold may be placed on your card upon check-in.", lastUpdated: "March 2026" },
  { id: "children", title: "Children & Extra Bed Policy", content: "Children of all ages are welcome. Children up to 3 years stay free in an existing bed. Extra beds may be available upon request for certain room types. The Apartment is recommended for families.", lastUpdated: "March 2026" },
  { id: "pets", title: "Pet Policy", content: "Pets are not allowed at Ferdinand Boutique. Service animals are welcome with prior arrangement. Please contact us ahead of your stay to make necessary arrangements.", lastUpdated: "March 2026" },
  { id: "smoking", title: "Smoking Policy", content: "Ferdinand Boutique is entirely non-smoking. Smoking is not permitted in any rooms, corridors, or common areas. A cleaning fee will apply if evidence of smoking is found in the room.", lastUpdated: "March 2026" },
  { id: "damage", title: "Damage & Deposit Policy", content: "Guests are responsible for any damage caused during their stay. A security deposit may be required at check-in, refundable upon satisfactory inspection of the room at check-out.", lastUpdated: "March 2026" },
  { id: "privacy", title: "Privacy Policy", content: "We collect and process personal data in accordance with applicable data protection regulations (GDPR). Guest data is used solely for reservation management, communication, and legal obligations. Data is never sold to third parties.", lastUpdated: "March 2026" },
  { id: "cookies", title: "Cookies Policy", content: "Our website uses cookies to improve your browsing experience and provide personalized content. By continuing to use the website, you consent to the use of cookies. You can manage your preferences in your browser settings.", lastUpdated: "March 2026" },
  { id: "terms", title: "Terms & Conditions", content: "By making a reservation, you agree to abide by the hotel's policies regarding check-in, check-out, cancellation, payment, and conduct during your stay. Ferdinand Boutique reserves the right to refuse service or cancel reservations in case of policy violations.", lastUpdated: "March 2026" },
];

const AdminPolicies = () => {
  const [policies, setPolicies] = useState(initialPolicies);
  const [editOpen, setEditOpen] = useState(false);
  const [editing, setEditing] = useState<Policy | null>(null);

  const openEdit = (p: Policy) => { setEditing({ ...p }); setEditOpen(true); };

  const save = () => {
    if (!editing) return;
    setPolicies(prev => prev.map(p => p.id === editing.id ? { ...editing, lastUpdated: "Just now" } : p));
    toast.success(`${editing.title} updated`);
    setEditOpen(false);
  };

  return (
    <div className="space-y-6">
      <p className="font-body text-sm text-muted-foreground">{policies.length} policy documents · Click Edit to update content</p>

      <div className="space-y-3">
        {policies.map(p => (
          <div key={p.id} className="bg-card border border-border rounded-sm p-5">
            <div className="flex items-start justify-between mb-2">
              <div>
                <h3 className="font-body text-sm font-semibold text-foreground">{p.title}</h3>
                <p className="font-body text-xs text-muted-foreground">Last updated: {p.lastUpdated}</p>
              </div>
              <Button variant="outline" size="sm" className="rounded-sm gap-1 font-body" onClick={() => openEdit(p)}>
                <Edit size={14} /> Edit
              </Button>
            </div>
            <p className="font-body text-sm text-muted-foreground line-clamp-2">{p.content}</p>
          </div>
        ))}
      </div>

      <Sheet open={editOpen} onOpenChange={setEditOpen}>
        <SheetContent className="w-full sm:max-w-lg overflow-y-auto">
          {editing && (
            <>
              <SheetHeader><SheetTitle className="font-display">{editing.title}</SheetTitle></SheetHeader>
              <div className="space-y-4 mt-6">
                <div>
                  <Label className="font-body text-sm">Policy Content</Label>
                  <textarea
                    value={editing.content}
                    onChange={e => setEditing(p => p ? { ...p, content: e.target.value } : p)}
                    className="mt-1 w-full h-64 rounded-sm border border-input bg-background px-3 py-2 font-body text-sm resize-none focus:outline-none focus:ring-2 focus:ring-ring"
                  />
                </div>
                <div className="flex gap-3 pt-2">
                  <Button onClick={save} className="bg-primary text-primary-foreground rounded-sm font-body flex-1 gap-1"><Save size={14} /> Save</Button>
                  <Button variant="outline" onClick={() => setEditOpen(false)} className="rounded-sm font-body">Cancel</Button>
                </div>
              </div>
            </>
          )}
        </SheetContent>
      </Sheet>
    </div>
  );
};

export default AdminPolicies;

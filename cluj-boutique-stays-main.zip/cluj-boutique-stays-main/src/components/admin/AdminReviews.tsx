import { useState } from "react";
import { Plus, Edit, Trash2, Eye, EyeOff, Star, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";

interface Review {
  id: string;
  guestName: string;
  rating: number;
  text: string;
  source: string;
  stayDate: string;
  reviewDate: string;
  status: "approved" | "pending" | "hidden";
}

const initialReviews: Review[] = [
  { id: "1", guestName: "Elena M.", rating: 5, text: "Absolutely spotless rooms and such a fantastic location. Walking distance to everything!", source: "direct", stayDate: "2026-03-10", reviewDate: "2026-03-15", status: "approved" },
  { id: "2", guestName: "Marco B.", rating: 5, text: "One of the best boutique stays I've had in Transylvania. Will definitely return.", source: "booking", stayDate: "2026-03-05", reviewDate: "2026-03-12", status: "approved" },
  { id: "3", guestName: "Sophie L.", rating: 5, text: "Loved the apartment — it had everything we needed for a family stay.", source: "direct", stayDate: "2026-02-28", reviewDate: "2026-03-08", status: "approved" },
  { id: "4", guestName: "Ana T.", rating: 4, text: "Very clean and central. The staff was incredibly helpful.", source: "booking", stayDate: "2026-03-12", reviewDate: "2026-03-20", status: "pending" },
  { id: "5", guestName: "James W.", rating: 3, text: "Good location but the room was smaller than expected.", source: "manual", stayDate: "2026-03-01", reviewDate: "2026-03-10", status: "hidden" },
];

const AdminReviews = () => {
  const [reviews, setReviews] = useState(initialReviews);
  const [filterStatus, setFilterStatus] = useState("all");
  const [editOpen, setEditOpen] = useState(false);
  const [editing, setEditing] = useState<Review | null>(null);

  const filtered = filterStatus === "all" ? reviews : reviews.filter(r => r.status === filterStatus);
  const avgRating = (reviews.reduce((s, r) => s + r.rating, 0) / reviews.length).toFixed(1);
  const approved = reviews.filter(r => r.status === "approved").length;
  const pending = reviews.filter(r => r.status === "pending").length;
  const hidden = reviews.filter(r => r.status === "hidden").length;

  const openEdit = (r: Review) => { setEditing({ ...r }); setEditOpen(true); };
  const openAdd = () => { setEditing({ id: "", guestName: "", rating: 5, text: "", source: "direct", stayDate: "", reviewDate: new Date().toISOString().split("T")[0], status: "pending" }); setEditOpen(true); };

  const save = () => {
    if (!editing) return;
    if (editing.id) {
      setReviews(prev => prev.map(r => r.id === editing.id ? editing : r));
      toast.success("Review updated");
    } else {
      setReviews(prev => [...prev, { ...editing, id: Date.now().toString() }]);
      toast.success("Review added");
    }
    setEditOpen(false);
  };

  const remove = (id: string) => { setReviews(prev => prev.filter(r => r.id !== id)); toast.success("Review deleted"); };
  const toggleStatus = (id: string, newStatus: Review["status"]) => {
    setReviews(prev => prev.map(r => r.id === id ? { ...r, status: newStatus } : r));
    toast.success(`Review ${newStatus}`);
  };

  return (
    <div className="space-y-6">
      {/* Stats */}
      <div className="grid grid-cols-4 gap-3">
        <div className="bg-card border border-border rounded-sm p-4 text-center">
          <p className="font-body text-xs text-muted-foreground uppercase tracking-wider">Avg. Rating</p>
          <p className="font-display text-2xl font-semibold text-foreground">{avgRating}</p>
        </div>
        <div className="bg-card border border-border rounded-sm p-4 text-center">
          <p className="font-body text-xs text-muted-foreground uppercase tracking-wider">Approved</p>
          <p className="font-display text-2xl font-semibold text-green-600">{approved}</p>
        </div>
        <div className="bg-card border border-border rounded-sm p-4 text-center">
          <p className="font-body text-xs text-muted-foreground uppercase tracking-wider">Pending</p>
          <p className="font-display text-2xl font-semibold text-yellow-600">{pending}</p>
        </div>
        <div className="bg-card border border-border rounded-sm p-4 text-center">
          <p className="font-body text-xs text-muted-foreground uppercase tracking-wider">Hidden</p>
          <p className="font-display text-2xl font-semibold text-muted-foreground">{hidden}</p>
        </div>
      </div>

      <div className="flex items-center justify-between">
        <Select value={filterStatus} onValueChange={setFilterStatus}>
          <SelectTrigger className="w-40 h-9 rounded-sm font-body text-sm"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Reviews</SelectItem>
            <SelectItem value="approved">Approved</SelectItem>
            <SelectItem value="pending">Pending</SelectItem>
            <SelectItem value="hidden">Hidden</SelectItem>
          </SelectContent>
        </Select>
        <Button onClick={openAdd} className="bg-primary text-primary-foreground hover:bg-primary/90 rounded-sm font-body gap-2">
          <Plus size={16} /> Add Review
        </Button>
      </div>

      <div className="space-y-3">
        {filtered.map(r => (
          <div key={r.id} className={`bg-card border border-border rounded-sm p-5 flex items-start gap-4 ${r.status === "hidden" ? "opacity-50" : ""}`}>
            <div className="w-10 h-10 rounded-full bg-secondary flex items-center justify-center flex-shrink-0">
              <span className="font-body text-sm font-semibold text-foreground">{r.guestName[0]}</span>
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex flex-wrap items-center gap-2 mb-1">
                <h3 className="font-body text-sm font-semibold text-foreground">{r.guestName}</h3>
                <div className="flex">{Array.from({ length: r.rating }).map((_, j) => <Star key={j} size={12} className="text-primary fill-primary" />)}</div>
                <span className="font-body text-[10px] uppercase tracking-wider px-1.5 py-0.5 rounded-sm bg-muted text-muted-foreground">{r.source}</span>
                <span className={`font-body text-[10px] uppercase tracking-wider px-1.5 py-0.5 rounded-sm ${
                  r.status === "approved" ? "bg-green-100 text-green-700" : r.status === "pending" ? "bg-yellow-100 text-yellow-700" : "bg-muted text-muted-foreground"
                }`}>{r.status}</span>
              </div>
              <p className="font-body text-sm text-muted-foreground">{r.text}</p>
              <p className="font-body text-xs text-muted-foreground mt-1">Stay: {r.stayDate} · Review: {r.reviewDate}</p>
            </div>
            <div className="flex gap-1 flex-shrink-0">
              {r.status !== "approved" && (
                <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => toggleStatus(r.id, "approved")} title="Approve"><Eye size={14} /></Button>
              )}
              {r.status !== "hidden" && (
                <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => toggleStatus(r.id, "hidden")} title="Hide"><EyeOff size={14} /></Button>
              )}
              <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => openEdit(r)}><Edit size={14} /></Button>
              <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive" onClick={() => remove(r.id)}><Trash2 size={14} /></Button>
            </div>
          </div>
        ))}
      </div>

      <Dialog open={editOpen} onOpenChange={setEditOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle className="font-display">{editing?.id ? "Edit Review" : "Add Review"}</DialogTitle></DialogHeader>
          {editing && (
            <div className="space-y-4 mt-2">
              <div><Label className="font-body text-sm">Guest Name</Label><Input value={editing.guestName} onChange={e => setEditing(p => p ? { ...p, guestName: e.target.value } : p)} className="mt-1 rounded-sm" /></div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="font-body text-sm">Rating</Label>
                  <Select value={String(editing.rating)} onValueChange={v => setEditing(p => p ? { ...p, rating: +v } : p)}>
                    <SelectTrigger className="mt-1 rounded-sm"><SelectValue /></SelectTrigger>
                    <SelectContent>{[5,4,3,2,1].map(n => <SelectItem key={n} value={String(n)}>{n} star{n > 1 ? "s" : ""}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="font-body text-sm">Source</Label>
                  <Select value={editing.source} onValueChange={v => setEditing(p => p ? { ...p, source: v } : p)}>
                    <SelectTrigger className="mt-1 rounded-sm"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="direct">Direct Guest</SelectItem>
                      <SelectItem value="booking">Booking Platform</SelectItem>
                      <SelectItem value="manual">Manual / Imported</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div><Label className="font-body text-sm">Review Text</Label><textarea value={editing.text} onChange={e => setEditing(p => p ? { ...p, text: e.target.value } : p)} className="mt-1 w-full h-24 rounded-sm border border-input bg-background px-3 py-2 font-body text-sm resize-none focus:outline-none focus:ring-2 focus:ring-ring" /></div>
              <div className="grid grid-cols-2 gap-4">
                <div><Label className="font-body text-sm">Stay Date</Label><Input type="date" value={editing.stayDate} onChange={e => setEditing(p => p ? { ...p, stayDate: e.target.value } : p)} className="mt-1 rounded-sm" /></div>
                <div><Label className="font-body text-sm">Review Date</Label><Input type="date" value={editing.reviewDate} onChange={e => setEditing(p => p ? { ...p, reviewDate: e.target.value } : p)} className="mt-1 rounded-sm" /></div>
              </div>
              <div>
                <Label className="font-body text-sm">Status</Label>
                <Select value={editing.status} onValueChange={v => setEditing(p => p ? { ...p, status: v as Review["status"] } : p)}>
                  <SelectTrigger className="mt-1 rounded-sm"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="approved">Approved</SelectItem>
                    <SelectItem value="pending">Pending</SelectItem>
                    <SelectItem value="hidden">Hidden</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex gap-3 pt-2">
                <Button onClick={save} className="bg-primary text-primary-foreground rounded-sm font-body flex-1">Save</Button>
                <Button variant="outline" onClick={() => setEditOpen(false)} className="rounded-sm font-body">Cancel</Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default AdminReviews;

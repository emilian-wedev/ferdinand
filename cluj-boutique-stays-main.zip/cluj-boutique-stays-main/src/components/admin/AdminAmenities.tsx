import { useState } from "react";
import { Plus, Edit, Trash2, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { allAmenities, amenityCategories, amenityIcons, AmenityItem } from "@/components/admin/amenitiesData";
import { toast } from "sonner";

const AdminAmenities = () => {
  const [amenities, setAmenities] = useState<AmenityItem[]>(allAmenities);
  const [search, setSearch] = useState("");
  const [filterCat, setFilterCat] = useState("All");
  const [editOpen, setEditOpen] = useState(false);
  const [editing, setEditing] = useState<AmenityItem | null>(null);

  const filtered = amenities
    .filter(a => filterCat === "All" || a.category === filterCat)
    .filter(a => a.title.toLowerCase().includes(search.toLowerCase()));

  const openEdit = (a: AmenityItem) => { setEditing({ ...a }); setEditOpen(true); };
  const openAdd = () => { setEditing({ id: "", title: "", description: "", category: amenityCategories[0], icon: "wifi", active: true }); setEditOpen(true); };

  const save = () => {
    if (!editing) return;
    if (editing.id) {
      setAmenities(prev => prev.map(a => a.id === editing.id ? editing : a));
      toast.success(`${editing.title} updated`);
    } else {
      const newItem = { ...editing, id: editing.title.toLowerCase().replace(/\s+/g, "-") };
      setAmenities(prev => [...prev, newItem]);
      toast.success(`${editing.title} added`);
    }
    setEditOpen(false);
  };

  const remove = (id: string) => {
    setAmenities(prev => prev.filter(a => a.id !== id));
    toast.success("Amenity removed");
  };

  const toggleActive = (id: string) => {
    setAmenities(prev => prev.map(a => a.id === id ? { ...a, active: !a.active } : a));
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="relative">
            <Search size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <Input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search amenities..." className="pl-8 w-48 h-9 rounded-sm font-body text-sm" />
          </div>
          <Select value={filterCat} onValueChange={setFilterCat}>
            <SelectTrigger className="w-36 h-9 rounded-sm font-body text-sm"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="All">All Categories</SelectItem>
              {amenityCategories.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <Button onClick={openAdd} className="bg-primary text-primary-foreground hover:bg-primary/90 rounded-sm font-body gap-2">
          <Plus size={16} /> Add Amenity
        </Button>
      </div>

      <p className="font-body text-xs text-muted-foreground">{filtered.length} amenities · Assign to rooms from the Room Editor</p>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-3">
        {filtered.map(a => {
          const Icon = amenityIcons[a.icon] || amenityIcons.wifi;
          return (
            <div key={a.id} className={`bg-card border border-border rounded-sm p-4 flex items-start gap-3 transition-opacity ${!a.active ? "opacity-50" : ""}`}>
              <div className="w-9 h-9 rounded-sm bg-secondary flex items-center justify-center flex-shrink-0">
                <Icon size={16} className="text-primary" />
              </div>
              <div className="flex-1 min-w-0">
                <h4 className="font-body text-sm font-medium text-foreground">{a.title}</h4>
                <p className="font-body text-xs text-muted-foreground">{a.description}</p>
                <span className="font-body text-[10px] uppercase tracking-wider text-muted-foreground">{a.category}</span>
              </div>
              <div className="flex items-center gap-1">
                <Switch checked={a.active} onCheckedChange={() => toggleActive(a.id)} className="scale-75" />
                <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => openEdit(a)}><Edit size={13} /></Button>
                <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive" onClick={() => remove(a.id)}><Trash2 size={13} /></Button>
              </div>
            </div>
          );
        })}
      </div>

      <Dialog open={editOpen} onOpenChange={setEditOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle className="font-display">{editing?.id ? "Edit Amenity" : "Add Amenity"}</DialogTitle></DialogHeader>
          {editing && (
            <div className="space-y-4 mt-2">
              <div>
                <Label className="font-body text-sm">Title</Label>
                <Input value={editing.title} onChange={e => setEditing(p => p ? { ...p, title: e.target.value } : p)} className="mt-1 rounded-sm" />
              </div>
              <div>
                <Label className="font-body text-sm">Description</Label>
                <Input value={editing.description} onChange={e => setEditing(p => p ? { ...p, description: e.target.value } : p)} className="mt-1 rounded-sm" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="font-body text-sm">Category</Label>
                  <Select value={editing.category} onValueChange={v => setEditing(p => p ? { ...p, category: v } : p)}>
                    <SelectTrigger className="mt-1 rounded-sm"><SelectValue /></SelectTrigger>
                    <SelectContent>{amenityCategories.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="font-body text-sm">Icon</Label>
                  <Select value={editing.icon} onValueChange={v => setEditing(p => p ? { ...p, icon: v } : p)}>
                    <SelectTrigger className="mt-1 rounded-sm"><SelectValue /></SelectTrigger>
                    <SelectContent>{Object.keys(amenityIcons).map(k => <SelectItem key={k} value={k}>{k}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <Switch checked={editing.active} onCheckedChange={v => setEditing(p => p ? { ...p, active: v } : p)} />
                <Label className="font-body text-sm">Active</Label>
              </div>
              <div className="flex gap-3 pt-2">
                <Button onClick={save} className="bg-primary text-primary-foreground rounded-sm font-body flex-1">Save</Button>
                <Button variant="outline" onClick={() => setEditOpen(false)} className="rounded-sm font-body">Cancel</Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default AdminAmenities;

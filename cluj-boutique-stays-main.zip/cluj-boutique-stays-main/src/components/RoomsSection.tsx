import { motion } from "framer-motion";
import { Users, Wifi, Wind, Bath } from "lucide-react";
import roomDouble from "@/assets/room-double.jpg";
import roomSingle from "@/assets/room-single.jpg";
import roomApartment from "@/assets/room-apartment.jpg";
import roomTriple from "@/assets/room-triple.jpg";

const BOOKING_URL = "https://ferdinand-boutique.pynbooking.direct/";

const rooms = [
  {
    name: "Double Room",
    image: roomDouble,
    guests: "2 guests",
    description: "Designed for couples who appreciate understated luxury. A generous double bed, warm lighting, and curated details create the perfect setting to unwind after a day discovering Cluj.",
    features: ["Double Bed", "Free Wi-Fi", "Air Conditioning", "Private Bathroom"],
  },
  {
    name: "Single Room",
    image: roomSingle,
    guests: "1 guest",
    description: "A refined solo retreat with everything you need — and nothing you don't. Compact yet elegant, ideal for the independent traveler who values quality and location above all.",
    features: ["Single Bed", "Free Wi-Fi", "Work Desk", "Private Bathroom"],
  },
  {
    name: "Apartment",
    image: roomApartment,
    guests: "Up to 4 guests",
    description: "Hotel comfort meets the freedom of home. A spacious apartment with a living area and kitchenette, perfect for families or longer stays where you want room to breathe.",
    features: ["Kitchenette", "Living Area", "Free Wi-Fi", "Up to 4 Guests"],
  },
  {
    name: "Triple Room",
    image: roomTriple,
    guests: "Up to 3 guests",
    description: "Spacious and social, our triple room is tailored for small groups and friends exploring Cluj together. Three comfortable beds, one shared adventure.",
    features: ["3 Beds", "Free Wi-Fi", "Air Conditioning", "Private Bathroom"],
  },
];

const featureIcon = (f: string) => {
  if (f.includes("Wi-Fi")) return <Wifi size={14} />;
  if (f.includes("Air")) return <Wind size={14} />;
  if (f.includes("Bathroom")) return <Bath size={14} />;
  return <Users size={14} />;
};

const RoomsSection = () => {
  return (
    <section id="rooms" className="py-24 lg:py-32 bg-surface">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <p className="font-body text-sm uppercase tracking-[0.2em] text-gold mb-4">Accommodations</p>
          <h2 className="font-display text-3xl md:text-4xl lg:text-5xl font-semibold text-foreground mb-4">
            Find Your Perfect Room
          </h2>
          <p className="font-body text-muted-foreground max-w-xl mx-auto">
            Four distinct room types, each crafted with care. From intimate singles to spacious apartments, every stay feels personal.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-8">
          {rooms.map((room, i) => (
            <motion.div
              key={room.name}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: i * 0.1 }}
              className="group bg-card rounded-sm overflow-hidden shadow-card hover:shadow-elevated transition-shadow duration-500"
            >
              <div className="relative overflow-hidden aspect-[4/3]">
                <img
                  src={room.image}
                  alt={`${room.name} at Ferdinand Boutique Cluj-Napoca`}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                  loading="lazy"
                />
                <div className="absolute top-4 right-4 bg-surface/90 backdrop-blur-sm px-3 py-1.5 rounded-sm">
                  <span className="font-body text-xs font-medium text-foreground flex items-center gap-1.5">
                    <Users size={12} className="text-gold" />
                    {room.guests}
                  </span>
                </div>
              </div>

              <div className="p-6 lg:p-8">
                <h3 className="font-display text-2xl font-semibold text-foreground mb-3">{room.name}</h3>
                <p className="font-body text-sm text-muted-foreground leading-relaxed mb-5">{room.description}</p>

                <div className="flex flex-wrap gap-2 mb-6">
                  {room.features.map((f) => (
                    <span key={f} className="inline-flex items-center gap-1.5 px-3 py-1 bg-secondary rounded-sm font-body text-xs text-muted-foreground">
                      {featureIcon(f)} {f}
                    </span>
                  ))}
                </div>

                <a
                  href={BOOKING_URL}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center px-6 py-3 bg-primary text-primary-foreground font-body text-sm font-semibold rounded-sm hover:bg-gold-dark transition-colors"
                >
                  Check Availability
                </a>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default RoomsSection;

import { motion } from "framer-motion";
import { MapPin } from "lucide-react";

const landmarks = [
  "Unirii Square",
  "Saint Michael's Church",
  "Banffy Palace",
  "Museum Square",
  "Heroes Street",
];

const LocationSection = () => {
  return (
    <section className="py-24 lg:py-32 bg-bone">
      <div className="container mx-auto px-4">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
          >
            <p className="font-body text-sm uppercase tracking-[0.2em] text-gold mb-4">Location</p>
            <h2 className="font-display text-3xl md:text-4xl lg:text-5xl font-semibold text-foreground mb-6 leading-tight">
              In the Heart of
              <br />
              <span className="italic text-gold">Cluj-Napoca</span>
            </h2>
            <p className="font-body text-muted-foreground leading-relaxed mb-8">
              Ferdinand Boutique is surrounded by the energy of central Cluj. Within minutes on foot, you'll find historic landmarks, artisan coffee shops, acclaimed restaurants, and lively terraces. Our street is the perfect starting point for every kind of exploration — cultural, culinary, or simply a good long walk.
            </p>

            <div className="space-y-3 mb-8">
              {landmarks.map((l) => (
                <div key={l} className="flex items-center gap-3">
                  <MapPin size={16} strokeWidth={1.5} className="text-gold flex-shrink-0" />
                  <span className="font-body text-sm text-foreground">{l}</span>
                </div>
              ))}
            </div>

            <p className="font-body text-xs text-muted-foreground">
              Regele Ferdinand nr 10, Cluj-Napoca, Județul Cluj
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7, delay: 0.2 }}
            className="rounded-sm overflow-hidden shadow-card"
          >
            <iframe
              title="Ferdinand Boutique Location"
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2732.8!2d23.5897!3d46.7712!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zNDbCsDQ2JzE2LjMiTiAyM8KwMzUnMjMuMCJF!5e0!3m2!1sen!2sro!4v1700000000000"
              width="100%"
              height="450"
              style={{ border: 0 }}
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              className="w-full"
            />
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default LocationSection;

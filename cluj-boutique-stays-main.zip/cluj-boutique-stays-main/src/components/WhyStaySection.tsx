import { motion } from "framer-motion";
import { MapPin, Sparkles, Wifi, Users, PenTool, DoorOpen, Ban, Accessibility } from "lucide-react";

const features = [
  { icon: MapPin, title: "Prime Central Location", desc: "Steps from Unirii Square, Saint Michael's Church, and the best of Cluj." },
  { icon: Sparkles, title: "Cleanliness & Comfort", desc: "Spotless rooms with premium linens and modern amenities throughout." },
  { icon: Wifi, title: "Fast Free Wi-Fi", desc: "High-speed internet in every room and common area — always on." },
  { icon: Users, title: "Family-Friendly Options", desc: "Rooms and apartments designed for families and small groups." },
  { icon: PenTool, title: "Quiet, Modern Design", desc: "Thoughtful interiors that balance warmth with contemporary elegance." },
  { icon: DoorOpen, title: "Smooth Stay Experience", desc: "Effortless self check-in and responsive support when you need it." },
  { icon: Ban, title: "Non-Smoking Environment", desc: "A clean, smoke-free environment for all our guests." },
  { icon: Accessibility, title: "Elevator Access", desc: "Easy access to all floors for comfort and convenience." },
];

const WhyStaySection = () => {
  return (
    <section id="why-us" className="py-24 lg:py-32 bg-surface">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <p className="font-body text-sm uppercase tracking-[0.2em] text-gold mb-4">Why Ferdinand Boutique</p>
          <h2 className="font-display text-3xl md:text-4xl lg:text-5xl font-semibold text-foreground mb-4">
            Why Stay With Us
          </h2>
          <p className="font-body text-muted-foreground max-w-xl mx-auto">
            Every detail is considered so you can focus on what matters — enjoying Cluj.
          </p>
        </motion.div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((f, i) => (
            <motion.div
              key={f.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: i * 0.05 }}
              className="text-center p-6"
            >
              <div className="inline-flex items-center justify-center w-14 h-14 rounded-full bg-secondary mb-5">
                <f.icon size={24} strokeWidth={1.5} className="text-gold" />
              </div>
              <h3 className="font-display text-lg font-semibold text-foreground mb-2">{f.title}</h3>
              <p className="font-body text-sm text-muted-foreground leading-relaxed">{f.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default WhyStaySection;

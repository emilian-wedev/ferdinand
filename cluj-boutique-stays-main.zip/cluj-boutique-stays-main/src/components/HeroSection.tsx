import { motion } from "framer-motion";
import heroImage from "@/assets/hero-hotel.jpg";

const BOOKING_URL = "https://ferdinand-boutique.pynbooking.direct/";

const HeroSection = () => {
  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden">
      <div className="absolute inset-0">
        <img
          src={heroImage}
          alt="Ferdinand Boutique hotel exterior on a charming Cluj-Napoca street at golden hour"
          className="w-full h-full object-cover"
          loading="eager"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-charcoal/60 via-charcoal/40 to-charcoal/70" />
      </div>

      <div className="relative z-10 container mx-auto px-4 text-center">
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="font-body text-sm md:text-base uppercase tracking-[0.3em] text-gold-light mb-6"
        >
          Less commute. More Cluj.
        </motion.p>

        <motion.h1
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="font-display text-4xl md:text-6xl lg:text-7xl font-semibold text-primary-foreground leading-tight mb-6"
        >
          Boutique Rooms in the
          <br />
          <span className="italic text-gold-light">Heart of Cluj-Napoca</span>
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="font-body text-base md:text-lg text-primary-foreground/80 max-w-2xl mx-auto mb-10 leading-relaxed"
        >
          Modern comfort meets old-world charm on Regele Ferdinand Street. Walk to top attractions, dine at the finest restaurants, and sleep in style — all from one central address.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.8 }}
          className="flex flex-col sm:flex-row items-center justify-center gap-4"
        >
          <a
            href={BOOKING_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="px-8 py-4 bg-primary text-primary-foreground font-body text-sm font-semibold uppercase tracking-wider rounded-sm hover:bg-gold-dark transition-colors"
          >
            Book Your Stay
          </a>
          <a
            href="#rooms"
            className="px-8 py-4 border border-primary-foreground/40 text-primary-foreground font-body text-sm font-semibold uppercase tracking-wider rounded-sm hover:bg-primary-foreground/10 transition-colors"
          >
            Explore Rooms
          </a>
        </motion.div>
      </div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.5, duration: 1 }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2"
      >
        <div className="w-6 h-10 border-2 border-primary-foreground/40 rounded-full flex justify-center pt-2">
          <motion.div
            animate={{ y: [0, 8, 0] }}
            transition={{ repeat: Infinity, duration: 1.5 }}
            className="w-1.5 h-1.5 rounded-full bg-gold-light"
          />
        </div>
      </motion.div>
    </section>
  );
};

export default HeroSection;

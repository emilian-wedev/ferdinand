import { motion } from "framer-motion";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const faqs = [
  {
    q: "What time is check-in and check-out?",
    a: "Check-in is from 15:00 and check-out is until 11:00. Early check-in or late check-out may be available upon request, subject to availability.",
  },
  {
    q: "Is Wi-Fi available?",
    a: "Yes, complimentary high-speed Wi-Fi is available in all rooms and common areas throughout the hotel.",
  },
  {
    q: "Are family rooms available?",
    a: "Absolutely. Our Apartment accommodates up to 4 guests and includes a kitchenette and living area — perfect for families. The Triple Room is also ideal for small groups.",
  },
  {
    q: "Is the hotel non-smoking?",
    a: "Yes, Ferdinand Boutique is a fully non-smoking property. We maintain a clean and healthy environment for all guests.",
  },
  {
    q: "Is there elevator access?",
    a: "Yes, the hotel is equipped with an elevator for easy access to all floors.",
  },
  {
    q: "How do I book a room?",
    a: "You can book directly through our website by clicking any 'Book Now' button, which will take you to our secure reservation system. You can also contact us by phone or WhatsApp.",
  },
  {
    q: "What is the cancellation policy?",
    a: "Our standard cancellation policy allows free cancellation up to 48 hours before your scheduled arrival. Cancellations made within 48 hours may be subject to a charge equivalent to the first night's stay. Please check your booking confirmation for specific terms.",
  },
];

const FAQSection = () => {
  return (
    <section id="faq" className="py-24 lg:py-32 bg-bone">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <p className="font-body text-sm uppercase tracking-[0.2em] text-gold mb-4">FAQ</p>
          <h2 className="font-display text-3xl md:text-4xl lg:text-5xl font-semibold text-foreground">
            Frequently Asked Questions
          </h2>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="max-w-3xl mx-auto"
        >
          <Accordion type="single" collapsible className="space-y-3">
            {faqs.map((faq, i) => (
              <AccordionItem key={i} value={`faq-${i}`} className="bg-surface rounded-sm px-6 border border-border">
                <AccordionTrigger className="font-display text-base md:text-lg font-medium text-foreground hover:no-underline py-5">
                  {faq.q}
                </AccordionTrigger>
                <AccordionContent className="font-body text-sm text-muted-foreground leading-relaxed pb-5">
                  {faq.a}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </motion.div>
      </div>
    </section>
  );
};

export default FAQSection;

import { useState } from "react";
import { format } from "date-fns";
import { CalendarIcon, Users, Search } from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { BOOKING_URL } from "@/lib/roomData";

interface BookingSearchBarProps {
  className?: string;
  variant?: "horizontal" | "compact";
}

const BookingSearchBar = ({ className, variant = "horizontal" }: BookingSearchBarProps) => {
  const [checkIn, setCheckIn] = useState<Date>();
  const [checkOut, setCheckOut] = useState<Date>();
  const [guests, setGuests] = useState(2);

  const handleSearch = () => {
    const params = new URLSearchParams();
    if (checkIn) params.set("checkin", format(checkIn, "yyyy-MM-dd"));
    if (checkOut) params.set("checkout", format(checkOut, "yyyy-MM-dd"));
    params.set("guests", guests.toString());
    window.open(`${BOOKING_URL}?${params.toString()}`, "_blank", "noopener,noreferrer");
  };

  return (
    <div className={cn(
      "bg-card border border-border rounded-sm shadow-card",
      variant === "horizontal" ? "p-4 lg:p-6" : "p-4",
      className
    )}>
      <div className={cn(
        "flex gap-3",
        variant === "horizontal" ? "flex-col md:flex-row md:items-end" : "flex-col"
      )}>
        {/* Check-in */}
        <div className="flex-1">
          <label className="font-body text-xs uppercase tracking-wider text-muted-foreground mb-1.5 block">Check-in</label>
          <Popover>
            <PopoverTrigger asChild>
              <Button variant="outline" className={cn(
                "w-full justify-start text-left font-body h-12 rounded-sm border-border",
                !checkIn && "text-muted-foreground"
              )}>
                <CalendarIcon className="mr-2 h-4 w-4 text-primary" />
                {checkIn ? format(checkIn, "EEE, MMM d") : "Select date"}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0" align="start">
              <Calendar
                mode="single"
                selected={checkIn}
                onSelect={setCheckIn}
                disabled={(date) => date < new Date()}
                initialFocus
                className="p-3 pointer-events-auto"
              />
            </PopoverContent>
          </Popover>
        </div>

        {/* Check-out */}
        <div className="flex-1">
          <label className="font-body text-xs uppercase tracking-wider text-muted-foreground mb-1.5 block">Check-out</label>
          <Popover>
            <PopoverTrigger asChild>
              <Button variant="outline" className={cn(
                "w-full justify-start text-left font-body h-12 rounded-sm border-border",
                !checkOut && "text-muted-foreground"
              )}>
                <CalendarIcon className="mr-2 h-4 w-4 text-primary" />
                {checkOut ? format(checkOut, "EEE, MMM d") : "Select date"}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0" align="start">
              <Calendar
                mode="single"
                selected={checkOut}
                onSelect={setCheckOut}
                disabled={(date) => date < (checkIn || new Date())}
                initialFocus
                className="p-3 pointer-events-auto"
              />
            </PopoverContent>
          </Popover>
        </div>

        {/* Guests */}
        <div className={variant === "horizontal" ? "w-full md:w-40" : ""}>
          <label className="font-body text-xs uppercase tracking-wider text-muted-foreground mb-1.5 block">Guests</label>
          <div className="flex items-center h-12 border border-border rounded-sm px-3">
            <Users className="h-4 w-4 text-primary mr-2" />
            <button onClick={() => setGuests(Math.max(1, guests - 1))} className="w-8 h-8 flex items-center justify-center text-muted-foreground hover:text-foreground font-body">−</button>
            <span className="flex-1 text-center font-body text-sm font-medium">{guests}</span>
            <button onClick={() => setGuests(Math.min(6, guests + 1))} className="w-8 h-8 flex items-center justify-center text-muted-foreground hover:text-foreground font-body">+</button>
          </div>
        </div>

        {/* Search */}
        <Button
          onClick={handleSearch}
          className="h-12 px-8 bg-primary text-primary-foreground hover:bg-gold-dark font-body font-semibold rounded-sm"
        >
          <Search className="h-4 w-4 mr-2" />
          Search
        </Button>
      </div>
    </div>
  );
};

export default BookingSearchBar;

import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { Users, Wifi, Wind, Bath, ArrowRight, Maximize } from "lucide-react";
import { RoomType, BOOKING_URL } from "@/lib/roomData";

interface RoomCardProps {
  room: RoomType;
  index?: number;
  variant?: "grid" | "list";
}

const featureIcon = (f: string) => {
  if (f.includes("Wi-Fi")) return <Wifi size={14} />;
  if (f.includes("Air")) return <Wind size={14} />;
  if (f.includes("Bathroom")) return <Bath size={14} />;
  return <Users size={14} />;
};

const RoomCard = ({ room, index = 0, variant = "grid" }: RoomCardProps) => {
  if (variant === "list") {
    return (
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: index * 0.1 }}
        className="group bg-card rounded-sm overflow-hidden shadow-card hover:shadow-elevated transition-all duration-500 flex flex-col md:flex-row"
      >
        <div className="relative overflow-hidden md:w-2/5 aspect-[4/3] md:aspect-auto">
          <Link to={`/rooms/${room.slug}`}>
            <img
              src={room.images[0]}
              alt={`${room.name} at Ferdinand Boutique`}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
              loading="lazy"
            />
          </Link>
          {room.tag && (
            <div className="absolute top-4 left-4">
              <span className="px-3 py-1 bg-primary text-primary-foreground font-body text-xs font-semibold uppercase tracking-wider rounded-sm">
                {room.tag}
              </span>
            </div>
          )}
        </div>
        <div className="flex-1 p-6 lg:p-8 flex flex-col justify-between">
          <div>
            <div className="flex items-start justify-between mb-3">
              <Link to={`/rooms/${room.slug}`}>
                <h3 className="font-display text-2xl font-semibold text-foreground hover:text-primary transition-colors">{room.name}</h3>
              </Link>
              <div className="text-right ml-4">
                <p className="font-body text-xs text-muted-foreground">from</p>
                <p className="font-display text-2xl font-semibold text-foreground">€{room.priceFrom}</p>
                <p className="font-body text-xs text-muted-foreground">/ night</p>
              </div>
            </div>
            <div className="flex items-center gap-4 mb-3 font-body text-sm text-muted-foreground">
              <span className="flex items-center gap-1"><Users size={14} className="text-primary" /> {room.guestsLabel}</span>
              <span className="flex items-center gap-1"><Maximize size={14} className="text-primary" /> {room.size}</span>
              <span>{room.beds}</span>
            </div>
            <p className="font-body text-sm text-muted-foreground leading-relaxed mb-4">{room.shortDescription}</p>
            <div className="flex flex-wrap gap-2 mb-6">
              {room.features.map((f) => (
                <span key={f} className="inline-flex items-center gap-1.5 px-3 py-1 bg-secondary rounded-sm font-body text-xs text-muted-foreground">
                  {featureIcon(f)} {f}
                </span>
              ))}
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Link
              to={`/rooms/${room.slug}`}
              className="inline-flex items-center gap-2 px-6 py-3 border border-border rounded-sm font-body text-sm font-medium text-foreground hover:border-primary hover:text-primary transition-colors"
            >
              View Details <ArrowRight size={14} />
            </Link>
            <a
              href={BOOKING_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center px-6 py-3 bg-primary text-primary-foreground font-body text-sm font-semibold rounded-sm hover:bg-gold-dark transition-colors"
            >
              Book Now
            </a>
          </div>
        </div>
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      className="group bg-card rounded-sm overflow-hidden shadow-card hover:shadow-elevated transition-all duration-500"
    >
      <div className="relative overflow-hidden aspect-[4/3]">
        <Link to={`/rooms/${room.slug}`}>
          <img
            src={room.images[0]}
            alt={`${room.name} at Ferdinand Boutique`}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
            loading="lazy"
          />
        </Link>
        {room.tag && (
          <div className="absolute top-4 left-4">
            <span className="px-3 py-1 bg-primary text-primary-foreground font-body text-xs font-semibold uppercase tracking-wider rounded-sm">
              {room.tag}
            </span>
          </div>
        )}
        <div className="absolute top-4 right-4 bg-card/90 backdrop-blur-sm px-3 py-1.5 rounded-sm">
          <span className="font-body text-xs font-medium text-foreground flex items-center gap-1.5">
            <Users size={12} className="text-primary" /> {room.guestsLabel}
          </span>
        </div>
      </div>
      <div className="p-6">
        <div className="flex items-start justify-between mb-2">
          <Link to={`/rooms/${room.slug}`}>
            <h3 className="font-display text-xl font-semibold text-foreground hover:text-primary transition-colors">{room.name}</h3>
          </Link>
          <div className="text-right">
            <p className="font-display text-xl font-semibold text-foreground">€{room.priceFrom}</p>
            <p className="font-body text-xs text-muted-foreground">/ night</p>
          </div>
        </div>
        <p className="font-body text-sm text-muted-foreground leading-relaxed mb-4">{room.shortDescription}</p>
        <div className="flex flex-wrap gap-2 mb-5">
          {room.features.slice(0, 3).map((f) => (
            <span key={f} className="inline-flex items-center gap-1 px-2.5 py-1 bg-secondary rounded-sm font-body text-xs text-muted-foreground">
              {featureIcon(f)} {f}
            </span>
          ))}
        </div>
        <div className="flex items-center gap-2">
          <Link
            to={`/rooms/${room.slug}`}
            className="flex-1 inline-flex items-center justify-center gap-2 px-4 py-2.5 border border-border rounded-sm font-body text-sm font-medium text-foreground hover:border-primary hover:text-primary transition-colors"
          >
            Details <ArrowRight size={14} />
          </Link>
          <a
            href={BOOKING_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="flex-1 inline-flex items-center justify-center px-4 py-2.5 bg-primary text-primary-foreground font-body text-sm font-semibold rounded-sm hover:bg-gold-dark transition-colors"
          >
            Book Now
          </a>
        </div>
      </div>
    </motion.div>
  );
};

export default RoomCard;

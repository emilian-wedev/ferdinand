import { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { Menu, X, User } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

const BOOKING_URL = "https://ferdinand-boutique.pynbooking.direct/";

const navLinks = [
  { label: "Home", href: "/#home" },
  { label: "Rooms", href: "/booking" },
  { label: "About", href: "/#about" },
  { label: "Why Stay With Us", href: "/#why-us" },
  { label: "Reviews", href: "/#reviews" },
  { label: "FAQ", href: "/#faq" },
  { label: "Contact", href: "/#contact" },
];

const Header = () => {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        scrolled
          ? "bg-surface/95 backdrop-blur-md shadow-soft"
          : "bg-transparent"
      }`}
    >
      <div className="container mx-auto flex items-center justify-between py-4 px-4 lg:px-8">
        <Link to="/" className="font-display text-xl md:text-2xl font-semibold tracking-tight text-foreground">
          Ferdinand <span className="text-gold">Boutique</span>
        </Link>

        <nav className="hidden lg:flex items-center gap-8">
          {navLinks.map((link) => (
            link.href.startsWith("/#") ? (
              <a key={link.href} href={link.href} className="font-body text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">{link.label}</a>
            ) : (
              <Link key={link.href} to={link.href} className="font-body text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">{link.label}</Link>
            )
          ))}
        </nav>

        <div className="flex items-center gap-3">
          <Link to="/login" className="hidden md:flex items-center gap-1.5 font-body text-sm text-muted-foreground hover:text-foreground transition-colors">
            <User size={16} /> Sign In
          </Link>
          <Link
            to="/booking"
            className="hidden md:inline-flex items-center px-6 py-2.5 bg-primary text-primary-foreground font-body text-sm font-semibold rounded-sm hover:bg-gold-dark transition-colors"
          >
            Book Now
          </Link>

          <button
            onClick={() => setMobileOpen(!mobileOpen)}
            className="lg:hidden text-foreground"
            aria-label="Toggle menu"
          >
            {mobileOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="lg:hidden bg-surface border-t border-border"
          >
            <div className="container mx-auto py-6 px-4 flex flex-col gap-4">
              {navLinks.map((link) => (
                link.href.startsWith("/#") ? (
                  <a key={link.href} href={link.href} onClick={() => setMobileOpen(false)} className="font-body text-base text-foreground py-2 border-b border-border last:border-0">{link.label}</a>
                ) : (
                  <Link key={link.href} to={link.href} onClick={() => setMobileOpen(false)} className="font-body text-base text-foreground py-2 border-b border-border last:border-0">{link.label}</Link>
                )
              ))}
              <Link to="/login" onClick={() => setMobileOpen(false)} className="font-body text-base text-foreground py-2 border-b border-border">Sign In</Link>
              <Link
                to="/booking"
                onClick={() => setMobileOpen(false)}
                className="mt-2 inline-flex items-center justify-center px-6 py-3 bg-primary text-primary-foreground font-body text-sm font-semibold rounded-sm"
              >
                Book Now
              </Link>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
};

export default Header;

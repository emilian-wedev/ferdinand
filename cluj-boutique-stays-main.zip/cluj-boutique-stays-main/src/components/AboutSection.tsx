import { motion } from "framer-motion";
import aboutCity from "@/assets/about-city.jpg";
import aboutInterior from "@/assets/about-interior.jpg";

const fadeInUp = {
  hidden: { opacity: 0, y: 30 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.7 } },
};

const AboutSection = () => {
  return (
    <section id="about" className="py-24 lg:py-32 bg-bone">
      <div className="container mx-auto px-4">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
            variants={fadeInUp}
          >
            <p className="font-body text-sm uppercase tracking-[0.2em] text-gold mb-4">About the Hotel</p>
            <h2 className="font-display text-3xl md:text-4xl lg:text-5xl font-semibold text-foreground mb-6 leading-tight">
              A Boutique Retreat on
              <br />
              <span className="italic text-gold">Regele Ferdinand</span>
            </h2>
            <div className="space-y-4 font-body text-muted-foreground leading-relaxed">
              <p>
                Ferdinand Boutique sits at the heart of Cluj-Napoca, on one of the city's most celebrated streets. Steps from Unirii Square, Saint Michael's Church, and the vibrant café-lined boulevards, our hotel offers a refined base for exploring everything this dynamic city has to offer.
              </p>
              <p>
                Whether you're a couple seeking a romantic city break, a solo traveler on a cultural adventure, or a family looking for space and comfort, our thoughtfully designed rooms cater to every kind of journey.
              </p>
              <p>
                With modern amenities, a welcoming atmosphere, and a location that puts Cluj's finest attractions at your doorstep, Ferdinand Boutique is where urban elegance meets genuine Romanian hospitality.
              </p>
            </div>
          </motion.div>

          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
            variants={{ hidden: { opacity: 0, x: 30 }, visible: { opacity: 1, x: 0, transition: { duration: 0.7, delay: 0.2 } } }}
            className="grid grid-cols-2 gap-4"
          >
            <div className="space-y-4">
              <img
                src={aboutInterior}
                alt="Ferdinand Boutique elegant hotel interior with warm lighting"
                className="w-full h-64 object-cover rounded-sm shadow-card"
                loading="lazy"
              />
              <div className="bg-primary p-6 rounded-sm text-center">
                <p className="font-display text-3xl font-semibold text-primary-foreground">4</p>
                <p className="font-body text-sm text-primary-foreground/80 mt-1">Room Categories</p>
              </div>
            </div>
            <div className="space-y-4 pt-8">
              <div className="bg-secondary p-6 rounded-sm text-center">
                <p className="font-display text-3xl font-semibold text-foreground">★ 9.2</p>
                <p className="font-body text-sm text-muted-foreground mt-1">Guest Rating</p>
              </div>
              <img
                src={aboutCity}
                alt="Cluj-Napoca historic city square with gothic church and outdoor cafes"
                className="w-full h-64 object-cover rounded-sm shadow-card"
                loading="lazy"
              />
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;

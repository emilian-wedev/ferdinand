import { Instagram, Facebook, Mail } from "lucide-react";

const BOOKING_URL = "https://ferdinand-boutique.pynbooking.direct/";

const Footer = () => {
  return (
    <footer className="bg-foreground py-16">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-3 gap-12 mb-12">
          <div>
            <h3 className="font-display text-xl font-semibold text-background mb-4">
              Ferdinand <span className="text-gold">Boutique</span>
            </h3>
            <p className="font-body text-sm text-background/60 leading-relaxed">
              Boutique rooms in the heart of Cluj-Napoca. Modern comfort, central location, genuine hospitality.
            </p>
          </div>

          <div>
            <h4 className="font-body text-sm font-semibold uppercase tracking-wider text-background mb-4">Quick Links</h4>
            <nav className="flex flex-col gap-2">
              {["Home", "Rooms", "About", "Reviews", "FAQ", "Contact"].map((link) => (
                <a
                  key={link}
                  href={`#${link.toLowerCase()}`}
                  className="font-body text-sm text-background/60 hover:text-gold transition-colors"
                >
                  {link}
                </a>
              ))}
            </nav>
          </div>

          <div>
            <h4 className="font-body text-sm font-semibold uppercase tracking-wider text-background mb-4">Contact</h4>
            <div className="space-y-2 font-body text-sm text-background/60">
              <p>Regele Ferdinand nr 10</p>
              <p>Cluj-Napoca, Județul Cluj</p>
              <a href="tel:+40740228899" className="block hover:text-gold transition-colors">0740 228 899</a>
            </div>

            <div className="flex items-center gap-4 mt-6">
              <a href="#" aria-label="Instagram" className="text-background/40 hover:text-gold transition-colors">
                <Instagram size={20} />
              </a>
              <a href="#" aria-label="Facebook" className="text-background/40 hover:text-gold transition-colors">
                <Facebook size={20} />
              </a>
              <a href="mailto:info@ferdinand-boutique.ro" aria-label="Email" className="text-background/40 hover:text-gold transition-colors">
                <Mail size={20} />
              </a>
            </div>

            <a
              href={BOOKING_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center mt-6 px-6 py-3 bg-primary text-primary-foreground font-body text-sm font-semibold rounded-sm hover:bg-gold-dark transition-colors"
            >
              Book Now
            </a>
          </div>
        </div>

        <div className="border-t border-background/10 pt-8 text-center">
          <p className="font-body text-xs text-background/40">
            © {new Date().getFullYear()} Ferdinand Boutique Cluj-Napoca. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ChevronLeft, ChevronRight, Star } from "lucide-react";

const reviews = [
  { name: "Elena M.", country: "Romania", rating: 5, text: "Absolutely spotless rooms and such a fantastic location. We walked everywhere — Unirii Square, the church, amazing restaurants. Ferdinand Boutique was the perfect base." },
  { name: "Marco B.", country: "Italy", rating: 5, text: "One of the best boutique stays I've had in Transylvania. The design is modern and elegant, the bed was incredibly comfortable, and the neighborhood has so much character." },
  { name: "Sophie L.", country: "France", rating: 5, text: "Loved the apartment — it had everything we needed for a week in Cluj. Kitchenette, space for our family, and the location couldn't be better. Will return." },
  { name: "James R.", country: "UK", rating: 4, text: "Clean, stylish, and central. The check-in was smooth and the room was exactly as described. Great value for a boutique experience in the heart of the city." },
  { name: "Anna K.", country: "Germany", rating: 5, text: "The perfect city break. The triple room was spacious and well-designed, and being steps away from cafés and cultural sites made it an unforgettable stay." },
];

const ReviewsSection = () => {
  const [current, setCurrent] = useState(0);

  const next = () => setCurrent((c) => (c + 1) % reviews.length);
  const prev = () => setCurrent((c) => (c - 1 + reviews.length) % reviews.length);

  const review = reviews[current];

  return (
    <section id="reviews" className="py-24 lg:py-32 bg-surface">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <p className="font-body text-sm uppercase tracking-[0.2em] text-gold mb-4">Guest Reviews</p>
          <h2 className="font-display text-3xl md:text-4xl lg:text-5xl font-semibold text-foreground">
            What Our Guests Say
          </h2>
        </motion.div>

        <div className="max-w-3xl mx-auto">
          <AnimatePresence mode="wait">
            <motion.div
              key={current}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.4 }}
              className="text-center"
            >
              <div className="flex items-center justify-center gap-1 mb-6">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star
                    key={i}
                    size={20}
                    className={i < review.rating ? "text-gold fill-gold" : "text-border"}
                  />
                ))}
              </div>

              <blockquote className="font-display text-xl md:text-2xl text-foreground leading-relaxed mb-8 italic">
                "{review.text}"
              </blockquote>

              <p className="font-body text-sm font-semibold text-foreground">{review.name}</p>
              <p className="font-body text-xs text-muted-foreground mt-1">{review.country}</p>
            </motion.div>
          </AnimatePresence>

          <div className="flex items-center justify-center gap-6 mt-12">
            <button
              onClick={prev}
              className="w-10 h-10 rounded-full border border-border flex items-center justify-center hover:border-gold hover:text-gold transition-colors"
              aria-label="Previous review"
            >
              <ChevronLeft size={18} />
            </button>
            <span className="font-body text-xs text-muted-foreground">
              {current + 1} / {reviews.length}
            </span>
            <button
              onClick={next}
              className="w-10 h-10 rounded-full border border-border flex items-center justify-center hover:border-gold hover:text-gold transition-colors"
              aria-label="Next review"
            >
              <ChevronRight size={18} />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ReviewsSection;

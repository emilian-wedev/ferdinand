import roomDouble from "@/assets/room-double.jpg";
import roomSingle from "@/assets/room-single.jpg";
import roomApartment from "@/assets/room-apartment.jpg";
import roomTriple from "@/assets/room-triple.jpg";

export const BOOKING_URL = "https://ferdinand-boutique.pynbooking.direct/";

export interface RoomType {
  id: string;
  name: string;
  slug: string;
  images: string[];
  guests: number;
  guestsLabel: string;
  beds: string;
  bathrooms: number;
  size: string;
  description: string;
  shortDescription: string;
  features: string[];
  amenities: string[];
  policies: string[];
  priceFrom: number;
  tag?: string;
}

export const rooms: RoomType[] = [
  {
    id: "double",
    name: "Double Room",
    slug: "double-room",
    images: [roomDouble, roomDouble, roomDouble],
    guests: 2,
    guestsLabel: "2 guests",
    beds: "1 Double Bed",
    bathrooms: 1,
    size: "22 m²",
    description: "Designed for couples who appreciate understated luxury. A generous double bed, warm lighting, and curated details create the perfect setting to unwind after a day discovering Cluj. The room features premium linens, blackout curtains, and a modern ensuite bathroom with rainfall shower. Every detail has been considered to make your stay feel personal and refined.",
    shortDescription: "Perfect for couples. Elegant, spacious, and central.",
    features: ["Double Bed", "Free Wi-Fi", "Air Conditioning", "Private Bathroom"],
    amenities: ["Free Wi-Fi", "Air Conditioning", "Flat Screen TV", "Premium Linens", "Blackout Curtains", "Rainfall Shower", "Hair Dryer", "Toiletries", "Safe", "Mini Fridge"],
    policies: ["Check-in from 15:00", "Check-out until 11:00", "Non-smoking", "Free cancellation up to 48h before arrival"],
    priceFrom: 65,
    tag: "Most Popular",
  },
  {
    id: "single",
    name: "Single Room",
    slug: "single-room",
    images: [roomSingle, roomSingle, roomSingle],
    guests: 1,
    guestsLabel: "1 guest",
    beds: "1 Single Bed",
    bathrooms: 1,
    size: "16 m²",
    description: "A refined solo retreat with everything you need — and nothing you don't. Compact yet elegant, ideal for the independent traveler who values quality and location above all. The room offers a comfortable single bed, a well-appointed work desk, and a pristine private bathroom. Smart storage and thoughtful design make the most of every square metre.",
    shortDescription: "A refined solo retreat in the heart of Cluj.",
    features: ["Single Bed", "Free Wi-Fi", "Work Desk", "Private Bathroom"],
    amenities: ["Free Wi-Fi", "Air Conditioning", "Flat Screen TV", "Work Desk", "Premium Linens", "Private Bathroom", "Hair Dryer", "Toiletries", "Safe"],
    policies: ["Check-in from 15:00", "Check-out until 11:00", "Non-smoking", "Free cancellation up to 48h before arrival"],
    priceFrom: 45,
  },
  {
    id: "apartment",
    name: "Apartment",
    slug: "apartment",
    images: [roomApartment, roomApartment, roomApartment],
    guests: 4,
    guestsLabel: "Up to 4 guests",
    beds: "1 Double Bed + Sofa Bed",
    bathrooms: 1,
    size: "40 m²",
    description: "Hotel comfort meets the freedom of home. A spacious apartment with a living area and kitchenette, perfect for families or longer stays where you want room to breathe. The open-plan layout includes a fully equipped kitchenette, a comfortable living area with sofa bed, and a separate sleeping zone with a premium double bed. Ideal for families, couples seeking extra space, or extended stays.",
    shortDescription: "Hotel luxury with the freedom of a private apartment.",
    features: ["Kitchenette", "Living Area", "Free Wi-Fi", "Up to 4 Guests"],
    amenities: ["Free Wi-Fi", "Air Conditioning", "Flat Screen TV", "Full Kitchenette", "Living Area", "Sofa Bed", "Dining Table", "Premium Linens", "Washing Machine", "Private Bathroom", "Hair Dryer", "Toiletries", "Safe", "Iron"],
    policies: ["Check-in from 15:00", "Check-out until 11:00", "Non-smoking", "Free cancellation up to 48h before arrival"],
    priceFrom: 95,
    tag: "Best for Families",
  },
  {
    id: "triple",
    name: "Triple Room",
    slug: "triple-room",
    images: [roomTriple, roomTriple, roomTriple],
    guests: 3,
    guestsLabel: "Up to 3 guests",
    beds: "3 Single Beds",
    bathrooms: 1,
    size: "28 m²",
    description: "Spacious and social, our triple room is tailored for small groups and friends exploring Cluj together. Three comfortable beds, generous space, and a modern bathroom make this the ideal base for shared adventures. The room's smart layout ensures privacy and comfort for each guest while maintaining a warm, connected atmosphere.",
    shortDescription: "Three beds, one unforgettable Cluj experience.",
    features: ["3 Beds", "Free Wi-Fi", "Air Conditioning", "Private Bathroom"],
    amenities: ["Free Wi-Fi", "Air Conditioning", "Flat Screen TV", "3 Single Beds", "Premium Linens", "Private Bathroom", "Hair Dryer", "Toiletries", "Safe", "Wardrobe"],
    policies: ["Check-in from 15:00", "Check-out until 11:00", "Non-smoking", "Free cancellation up to 48h before arrival"],
    priceFrom: 85,
    tag: "Group Favorite",
  },
];

export const getRoomBySlug = (slug: string): RoomType | undefined => {
  return rooms.find((r) => r.slug === slug);
};
